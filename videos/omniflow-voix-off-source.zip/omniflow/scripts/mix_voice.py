#!/usr/bin/env python3
"""Mix the frozen French voice with the original 120 BPM sound design.

Requires Python 3, NumPy and ffmpeg. All inputs are frozen local WAV files.
Music is spectrally carved and ducked underneath measured speech ranges;
transition sounds retain their impact outside narration. This mastering step
is offline: HyperFrames only decodes the finished 15-second stereo master.
"""
from __future__ import annotations

import argparse
import json
import math
import subprocess
import tempfile
import wave
from pathlib import Path

import numpy as np

SR = 48_000
N = 15 * SR


def read_wav(path: Path) -> np.ndarray:
    with wave.open(str(path), 'rb') as wav:
        if (wav.getframerate(), wav.getsampwidth()) != (SR, 2):
            raise ValueError(f'{path.name}: expected 48 kHz PCM16')
        channels = wav.getnchannels()
        signal = np.frombuffer(wav.readframes(wav.getnframes()), dtype='<i2').astype(np.float64)
    signal = signal.reshape(-1, channels) / 32768
    if channels == 1:
        signal = np.repeat(signal, 2, axis=1)
    if len(signal) != N:
        raise ValueError(f'{path.name}: expected exactly 15 seconds')
    return signal


def write_wav(path: Path, signal: np.ndarray) -> None:
    if np.max(np.abs(signal)) >= 1:
        raise ValueError(f'{path.name}: clipping before writing')
    with wave.open(str(path), 'wb') as wav:
        wav.setnchannels(2)
        wav.setsampwidth(2)
        wav.setframerate(SR)
        wav.writeframes(np.round(signal * 32767).astype('<i2').tobytes())


def meter(path: Path) -> dict:
    result = subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-i', str(path),
                             '-af', 'loudnorm=I=-16:TP=-1.8:LRA=7:print_format=json',
                             '-f', 'null', '-'], check=True, capture_output=True, text=True)
    return json.loads(result.stderr[result.stderr.rfind('{'):result.stderr.rfind('}') + 1])


def envelope(takes: list[dict]) -> np.ndarray:
    t = np.arange(N) / SR
    result = np.zeros(N)
    for take in takes:
        start, end = take['start'], take['end']
        attack = np.clip((t - start + 0.10) / 0.10, 0, 1)
        release = np.clip((end + 0.25 - t) / 0.25, 0, 1)
        # Smooth attack/release, so the bed returns naturally in speech gaps.
        local = np.minimum(attack, release)
        local = local * local * (3 - 2 * local)
        result = np.maximum(result, local)
    return result


def main(audio_dir: Path) -> None:
    cues = json.loads((audio_dir / 'voice-cues.json').read_text(encoding='utf-8'))
    speech = read_wav(audio_dir / 'voice-stem.wav')
    music = read_wav(audio_dir / 'music-stem.wav')
    transitions = read_wav(audio_dir / 'transitions-stem.wav')
    ui = read_wav(audio_dir / 'ui-stem.wav')
    logo = read_wav(audio_dir / 'logo-stem.wav')
    duck = envelope(cues['takes'])

    with tempfile.TemporaryDirectory(prefix='voice-mix-', dir=str(audio_dir)) as temp:
        temp_dir = Path(temp)
        carved_file = temp_dir / 'carved-music.wav'
        subprocess.run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error',
                        '-i', str(audio_dir / 'music-stem.wav'), '-af',
                        'equalizer=f=350:t=q:w=0.9:g=-3,equalizer=f=1600:t=q:w=0.8:g=-6,'
                        'equalizer=f=2800:t=q:w=1.0:g=-4',
                        '-ar', str(SR), '-ac', '2', '-c:a', 'pcm_s16le', str(carved_file)], check=True)
        carved = read_wav(carved_file)
        music_mix = (music * (1 - duck[:, None]) + carved * duck[:, None])
        music_mix *= (1 - duck[:, None] * 0.67)  # −9.6 dB active speech duck.
        # SFX receive a lighter reduction under speech; cuts remain audible.
        effects = (transitions * 0.86 + ui * 0.86 + logo * 0.80)
        effects *= (1 - duck[:, None] * 0.52)

        # Additional cursor click on the final CTA at 13.30 s, matching V2.
        click_time = np.arange(round(0.065 * SR)) / SR
        click = np.sin(2 * np.pi * 2480 * click_time)
        click *= (1 - np.exp(-click_time / 0.0007)) * np.exp(-click_time / 0.011)
        click *= 0.033
        at = round(13.30 * SR)
        effects[at:at + len(click), 0] += click
        effects[at:at + len(click), 1] += click

        background = music_mix + effects
        premaster = speech + background
        raw = temp_dir / 'premaster.wav'
        peak = np.max(np.abs(premaster))
        premaster_gain = min(1.0, 0.90 / peak)
        write_wav(raw, premaster * premaster_gain)
        measured = meter(raw)
        gain_db = min(-16.0 - float(measured['input_i']), -1.8 - float(measured['input_tp']))
        gain = premaster_gain * 10 ** (gain_db / 20)
        master = premaster * gain
        write_wav(audio_dir / 'voice-master.wav', master)
        write_wav(audio_dir / 'ducked-background.wav', background * gain)
        write_wav(audio_dir / 'voice-mix-stem.wav', speech * gain)
    final = meter(audio_dir / 'voice-master.wav')
    info = {
        'master': 'voice-master.wav', 'durationSeconds': 15, 'sampleRate': SR,
        'channels': 2, 'pcmBits': 16,
        'integratedLUFS': float(final['input_i']), 'truePeakDbTP': float(final['input_tp']),
        'loudnessRangeLU': float(final['input_lra']),
        'samplePeakDbFS': round(20 * math.log10(float(np.max(np.abs(master)))), 3),
        'musicDuckDb': -9.63, 'sfxDuckDb': -6.38,
        'spectralCarve': [{'frequencyHz': 350, 'gainDb': -3},
                          {'frequencyHz': 1600, 'gainDb': -6},
                          {'frequencyHz': 2800, 'gainDb': -4}],
        'duckAttackSeconds': 0.10, 'duckReleaseSeconds': 0.25,
        'additionalCtaClickTime': 13.30,
        'voiceRanges': [{'id': t['id'], 'start': t['start'], 'end': t['end'],
                         'text': t['text']} for t in cues['takes']],
    }
    (audio_dir / 'voice-mix.json').write_text(json.dumps(info, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(info, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--audio-dir', type=Path,
                        default=Path(__file__).resolve().parent.parent / 'assets' / 'audio')
    args = parser.parse_args()
    main(args.audio_dir)
