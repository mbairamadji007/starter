#!/usr/bin/env python3
"""OmniFlow: original, reproducible 15-second stereo sound design.

Requires Python 3, NumPy and ffmpeg. No network, samples or proprietary media.
All renders use a fixed PRNG seed; only the finished PCM WAV enters HyperFrames.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
import subprocess
import tempfile
import wave
from pathlib import Path

import numpy as np

SR = 48_000
DURATION = 15.0
N = int(SR * DURATION)
SEED = 140_120_060
RNG = np.random.default_rng(SEED)
TARGET_LUFS = -16.0
TRUE_PEAK_CEILING_DB = -1.8


def timebase(seconds: float) -> np.ndarray:
    return np.arange(round(seconds * SR), dtype=np.float64) / SR


def fade_edges(signal: np.ndarray, attack: float = 0.004, release: float = 0.018) -> np.ndarray:
    """Avoid digital edge clicks without delaying the cue's timeline anchor."""
    out = signal.copy()
    a = min(len(out), round(attack * SR))
    r = min(len(out), round(release * SR))
    if a:
        out[:a] *= np.sin(np.linspace(0, np.pi / 2, a)) ** 2
    if r:
        out[-r:] *= np.cos(np.linspace(0, np.pi / 2, r)) ** 2
    return out


def band_noise(seconds: float, lo: float, hi: float) -> np.ndarray:
    """Smooth spectral roll-offs produce airy, restrained noise rather than hiss."""
    count = round(seconds * SR)
    noise = RNG.standard_normal(count)
    spectrum = np.fft.rfft(noise)
    f = np.fft.rfftfreq(count, 1 / SR)
    weight = (1 - np.exp(-((f / lo) ** 4))) * np.exp(-((f / hi) ** 4))
    out = np.fft.irfft(spectrum * weight, n=count)
    return out / max(np.sqrt(np.mean(out**2)), 1e-12)


def stereo(signal: np.ndarray, pan: float = 0.0) -> np.ndarray:
    angle = (np.clip(pan, -1, 1) + 1) * np.pi / 4
    return np.column_stack((signal * np.cos(angle), signal * np.sin(angle)))


def add(track: np.ndarray, signal: np.ndarray, at: float, gain: float = 1.0, pan: float = 0.0) -> None:
    if signal.ndim == 1:
        signal = stereo(signal, pan)
    start = round(at * SR)
    # Negative starts intentionally support a swell leading into frame zero.
    offset = max(0, -start)
    start = max(0, start)
    length = min(len(signal) - offset, len(track) - start)
    if length > 0:
        track[start : start + length] += signal[offset : offset + length] * gain


def short_space(signal: np.ndarray, wet: float = 0.22) -> np.ndarray:
    """Six decorrelated stereo taps: compact studio space, no long muddy tail."""
    dry = stereo(signal)
    out = dry.copy()
    for delay, level, pan in ((0.041, 0.55, -0.8), (0.067, 0.46, 0.9),
                              (0.109, 0.31, -0.65), (0.167, 0.23, 0.72),
                              (0.239, 0.15, -0.4), (0.313, 0.09, 0.45)):
        shift = round(delay * SR)
        if shift < len(signal):
            out[shift:] += stereo(signal[:-shift], pan) * wet * level
    return out


def pluck(freq: float, seconds: float = 0.44, bright: float = 0.22) -> np.ndarray:
    t = timebase(seconds)
    env = (1 - np.exp(-t / 0.002)) * np.exp(-t / 0.105)
    # Sine core with small, rapidly decaying harmonic sheen.
    signal = np.sin(2 * np.pi * freq * t)
    signal += bright * np.sin(4 * np.pi * freq * t) * np.exp(-t / 0.045)
    signal += bright * 0.22 * np.sin(6 * np.pi * freq * t) * np.exp(-t / 0.03)
    return fade_edges(signal * env)


def kick(seconds: float = 0.36, weight: float = 1.0) -> np.ndarray:
    t = timebase(seconds)
    phase = 2 * np.pi * (46 * t + 88 * 0.022 * (1 - np.exp(-t / 0.022)))
    env = (1 - np.exp(-t / 0.0012)) * np.exp(-t / 0.080)
    body = np.sin(phase) * env
    transient = band_noise(seconds, 500, 1800) * np.exp(-t / 0.009) * 0.032
    return fade_edges((body + transient) * weight, 0.001, 0.014)


def tick(seconds: float = 0.10, note: float = 2300) -> np.ndarray:
    t = timebase(seconds)
    noise = band_noise(seconds, 1500, 6400) * np.exp(-t / 0.008) * 0.16
    tone = np.sin(2 * np.pi * note * t) * np.exp(-t / 0.013)
    return fade_edges(tone * 0.8 + noise, 0.0008, 0.008)


def sub_drop(seconds: float = 0.90) -> np.ndarray:
    t = timebase(seconds)
    phase = 2 * np.pi * (36 * t + 90 * 0.060 * (1 - np.exp(-t / 0.060)))
    env = (1 - np.exp(-t / 0.003)) * np.exp(-t / 0.205)
    out = np.sin(phase) * env
    out += np.sin(phase * 2) * env * np.exp(-t / 0.11) * 0.17
    return fade_edges(out, 0.002, 0.040)


def whoosh(seconds: float = 0.70) -> np.ndarray:
    """Forward air motion peaking 80 ms after the cut, stereo sweep."""
    t = timebase(seconds)
    noise = band_noise(seconds, 420, 5400)
    env = (1 - np.exp(-t / 0.016)) * np.exp(-t / 0.150)
    chirp_phase = 2 * np.pi * (900 * t + 2000 * 0.09 * (1 - np.exp(-t / 0.09)))
    # Saturating only the synthetic air source restrains random noise peaks;
    # the finished four stems still sum linearly to the master.
    noise = np.tanh(noise / 1.6) * 1.45
    signal = fade_edges((noise * 0.095 + np.sin(chirp_phase) * 0.045) * env)
    pan = np.clip(-0.75 + 1.5 * t / seconds, -1, 1)
    angle = (pan + 1) * np.pi / 4
    return np.column_stack((signal * np.cos(angle), signal * np.sin(angle)))


def riser(seconds: float = 0.42) -> np.ndarray:
    t = timebase(seconds)
    x = t / seconds
    noise = band_noise(seconds, 550, 4400)
    chirp = np.sin(2 * np.pi * (430 * t + 1050 * t**2 / seconds))
    out = (noise * 0.115 + chirp * 0.055) * np.sin(x * np.pi / 2) ** 3
    return short_space(fade_edges(out, 0.016, 0.008), wet=0.28)


def logo_chord(seconds: float = 2.10) -> np.ndarray:
    t = timebase(seconds)
    env = (1 - np.exp(-t / 0.006)) * np.exp(-t / 0.50)
    # D6/9: a resolved, optimistic harmonic identity.
    tones = ((293.6648, 0.32), (369.9944, 0.30), (440.0, 0.23),
             (554.3653, 0.20), (659.2551, 0.16), (880.0, 0.10))
    y = np.zeros_like(t)
    for freq, level in tones:
        y += level * np.sin(2 * np.pi * freq * t + 0.14 * np.sin(2 * np.pi * 0.4 * t))
    sparkle = band_noise(seconds, 1800, 5800) * np.exp(-t / 0.020) * 0.12
    return short_space(fade_edges((y + sparkle) * env), wet=0.36)


def write_pcm(path: Path, signal: np.ndarray) -> None:
    if np.max(np.abs(signal), initial=0) >= 1:
        raise RuntimeError(f"Clipping would occur in {path.name}")
    pcm = np.round(np.clip(signal, -0.999969, 0.999969) * 32767).astype('<i2')
    with wave.open(str(path), 'wb') as wav:
        wav.setnchannels(2)
        wav.setsampwidth(2)
        wav.setframerate(SR)
        wav.writeframes(pcm.tobytes())


def meter(path: Path) -> dict:
    cmd = ['ffmpeg', '-hide_banner', '-nostats', '-i', str(path), '-af',
           'loudnorm=I=-16:TP=-1.8:LRA=7:print_format=json', '-f', 'null', '-']
    result = subprocess.run(cmd, check=True, capture_output=True, text=True)
    report = result.stderr[result.stderr.rfind('{') : result.stderr.rfind('}') + 1]
    return json.loads(report)


def generate(out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    tracks = {name: np.zeros((N, 2), dtype=np.float64) for name in
              ('music', 'transitions', 'ui', 'logo')}
    music = tracks['music']
    t = np.arange(N, dtype=np.float64) / SR

    # An unobtrusive F# minor floor; after 4 s it opens into D major colour.
    pad_gate = np.clip(t / 0.6, 0, 1) * np.clip((15 - t) / 1.25, 0, 1)
    pad = np.sin(2 * np.pi * 185.0 * t) * 0.014
    pad += np.sin(2 * np.pi * 277.1826 * t + 0.13 * np.sin(t * 0.82)) * 0.012
    music[:, 0] += pad * pad_gate
    music[:, 1] += pad * pad_gate
    open_gate = np.clip((t - 4) / 0.3, 0, 1) * np.clip((15 - t) / 1.1, 0, 1)
    for freq, level, offset in ((293.6648, 0.031, 0.0), (440.0, 0.026, 0.4),
                                (554.3653, 0.021, 1.0)):
        music[:, 0] += np.sin(2 * np.pi * freq * t + offset) * level * open_gate
        music[:, 1] += np.sin(2 * np.pi * (freq * 1.0003) * t + offset + 0.12) * level * open_gate

    # 120 BPM = one quarter note each 0.5 s. Sync points all lie on this grid.
    bass_notes = [92.4986, 92.4986, 110.0, 82.4069, 92.4986, 110.0, 82.4069, 73.4162]
    for beat in range(29):
        at = beat * 0.5
        add(music, kick(), at, 0.125 if beat % 4 else 0.145)
        add(music, pluck(bass_notes[beat % 8], bright=0.10), at + 0.012, 0.065)
        if beat % 2:
            add(music, tick(0.08, 1600), at, 0.024, pan=0.12)
        if at < 13.8:
            add(music, tick(0.065, 3400), at + 0.25, 0.014, pan=(-0.40 if beat % 2 else 0.40))

    motif = [369.9944, 440.0, 554.3653, 659.2551, 554.3653, 440.0, 369.9944, 293.6648]
    for step in range(32):
        at = 4.125 + step * 0.25
        add(music, short_space(pluck(motif[step % 8], 0.55), wet=0.24), at,
            0.050 if step % 4 == 0 else 0.035, pan=0)
    for step, at in enumerate((9.125, 9.375, 9.625, 9.875, 10.25, 10.50, 10.75, 11.0, 11.25, 11.5)):
        add(music, short_space(pluck(motif[step % 8] * 2, 0.48), wet=0.20), at, 0.018)

    for at, level in ((0.0, 0.92), (4.0, 1.00), (9.0, 0.85), (12.0, 1.08)):
        add(tracks['transitions'], whoosh(), at, level)
        add(tracks['transitions'], sub_drop(), at, 0.155 * level)
    for at, duration, level in ((3.58, 0.42, 0.85), (8.62, 0.38, 0.82), (11.55, 0.45, 0.92)):
        add(tracks['transitions'], riser(duration), at, level)

    # Kinetic headlines + lightning-fast panel assembly.
    for at, level in ((0.18, 0.06), (0.56, 0.06), (1.02, 0.07), (1.78, 0.08),
                      (2.14, 0.10), (4.18, 0.07), (4.34, 0.06), (4.50, 0.05),
                      (4.70, 0.05), (5.02, 0.055), (5.36, 0.04), (5.75, 0.04)):
        add(tracks['ui'], tick(0.09, 1900), at, level, pan=0.08)
    add(tracks['ui'], tick(0.11, 2450), 10.0, 0.15)
    add(tracks['ui'], short_space(pluck(1108.7305, 0.50), wet=0.25), 10.18, 0.068)
    for step, at in enumerate(np.arange(10.20, 10.70, 0.055)):
        add(tracks['ui'], tick(0.045, 1800 + step * 70), float(at), 0.018)
    add(tracks['ui'], short_space(pluck(880.0, 0.65), wet=0.18), 10.78, 0.09)

    add(tracks['logo'], riser(0.35), 12.0, 0.62)
    add(tracks['logo'], logo_chord(), 12.35, 0.16)
    add(tracks['logo'], sub_drop(0.70), 12.35, 0.12)
    add(tracks['logo'], tick(0.10, 2936.65), 13.15, 0.105)
    add(tracks['logo'], short_space(pluck(880.0, 1.00), wet=0.27), 13.15, 0.050)

    # Global release is baked into every stem and reaches absolute zero at 15 s.
    fade_start = 14.30
    release = np.ones(N)
    begin = round(fade_start * SR)
    release[begin:] = np.cos(np.linspace(0, np.pi / 2, N - begin)) ** 2
    release[-1] = 0
    for name in tracks:
        tracks[name] *= release[:, None]
    mix = sum(tracks.values())

    if not shutil.which('ffmpeg'):
        raise RuntimeError('ffmpeg must be installed for EBU R128 metering')
    with tempfile.TemporaryDirectory(prefix='omniflow-audio-', dir=str(out)) as temp:
        raw = Path(temp) / 'premaster.wav'
        write_pcm(raw, mix)
        measured = meter(raw)
    # R128 measurement + constant gain preserves transients and makes isolated
    # stems sum to the master, instead of hiding nonlinear mastering in a file.
    gain_db = min(TARGET_LUFS - float(measured['input_i']),
                  TRUE_PEAK_CEILING_DB - float(measured['input_tp']))
    gain = 10 ** (gain_db / 20)
    master = mix * gain
    write_pcm(out / 'sound-bed.wav', master)
    for name, signal in tracks.items():
        write_pcm(out / f'{name}-stem.wav', signal * gain)
    final_measurement = meter(out / 'sound-bed.wav')

    cue_data = {
        'durationSeconds': DURATION, 'sampleRate': SR, 'channels': 2,
        'format': 'PCM signed 16-bit little-endian WAV', 'bpm': 120,
        'seed': SEED, 'gainDb': round(gain_db, 3),
        'master': 'sound-bed.wav',
        'stems': {name: f'{name}-stem.wav' for name in tracks},
        'measured': {'integratedLUFS': float(final_measurement['input_i']),
                     'truePeakDbTP': float(final_measurement['input_tp']),
                     'loudnessRangeLU': float(final_measurement['input_lra']),
                     'samplePeakDbFS': round(20 * math.log10(float(np.max(np.abs(master)))), 3)},
        'cues': [
            {'time': 0.0, 'frame60': 0, 'kind': 'whoosh+sub', 'visual': 'Entrée brutale du dashboard fragmenté'},
            {'time': 2.14, 'frame60': 128, 'kind': 'headline-hit', 'visual': 'Punchline logistique'},
            {'time': 3.58, 'frame60': 215, 'kind': 'riser', 'visual': 'Préparation du flash technologique'},
            {'time': 4.0, 'frame60': 240, 'kind': 'whoosh+sub', 'visual': 'Flash et assemblage OmniFlow'},
            {'time': 4.18, 'frame60': 251, 'kind': 'ui-stack', 'visual': 'Cartes KPI en cascade'},
            {'time': 8.62, 'frame60': 517, 'kind': 'riser', 'visual': 'Préparation du travelling'},
            {'time': 9.0, 'frame60': 540, 'kind': 'whoosh+sub', 'visual': 'Caméra autour du mockup'},
            {'time': 10.0, 'frame60': 600, 'kind': 'ui-click', 'visual': 'Clic du curseur, compteur +140%'},
            {'time': 10.18, 'frame60': 611, 'kind': 'ripple-chime', 'visual': 'Onde émeraude du clic'},
            {'time': 10.78, 'frame60': 647, 'kind': 'success-chime', 'visual': 'Métrique finale stabilisée'},
            {'time': 11.55, 'frame60': 693, 'kind': 'riser', 'visual': 'Aspiration centrale'},
            {'time': 12.0, 'frame60': 720, 'kind': 'whoosh+sub', 'visual': 'Rassemblement des calques'},
            {'time': 12.35, 'frame60': 741, 'kind': 'logo-impact', 'visual': 'Logo OmniFlow révélé'},
            {'time': 13.15, 'frame60': 789, 'kind': 'cta-tick', 'visual': 'Bouton essai gratuit'},
            {'time': 14.30, 'frame60': 858, 'kind': 'fade-out', 'visual': 'Maintien CTA et sortie propre'},
        ],
    }
    (out / 'cues.json').write_text(json.dumps(cue_data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'output': str(out), 'frames': N, 'seconds': DURATION,
                      'measured': cue_data['measured'], 'files': sorted(p.name for p in out.iterdir() if p.is_file())},
                     ensure_ascii=False, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=Path(__file__).resolve().parent.parent / 'assets' / 'audio')
    args = parser.parse_args()
    generate(args.out)
