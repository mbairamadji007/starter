#!/usr/bin/env python3
"""Generate the frozen French OmniFlow narration with an offline neural voice.

Python dependencies: sherpa-onnx==1.13.8 numpy soundfile; ffmpeg on PATH.
Model: official sherpa-onnx release vits-piper-fr_FR-siwis-medium (22.05 kHz).
No model inference, network request or randomness happens during video playback.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import tempfile
from pathlib import Path

import numpy as np
import sherpa_onnx
import soundfile as sf

SR = 48_000
SECONDS = 15
LINES = [
    {'id': 'question', 'start': 0.35, 'latestEnd': 3.40, 'speed': 1.12,
     'text': 'Votre logistique vous échappe ?', 'spokenText': 'Votre logistique vous échappe ?'},
    {'id': 'dashboard', 'start': 4.25, 'latestEnd': 8.65, 'speed': 1.13,
     'text': 'OmniFlow. Un seul dashboard. Zéro latence.',
     'spokenText': 'Omni Flo. Un seul dashboard. Zéro latence.'},
    {'id': 'efficacite', 'start': 9.15, 'latestEnd': 11.90, 'speed': 1.16,
     'text': 'Plus cent quarante pour cent d’efficacité.',
     'spokenText': 'Plus cent quarante pour cent d’efficacité.'},
    {'id': 'essai', 'start': 13.00, 'latestEnd': 14.80, 'speed': 1.14,
     'text': 'Démarrez votre essai gratuit.', 'spokenText': 'Démarrez votre essai gratuit.'},
]


def run(model_dir: Path, out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    model_path = model_dir / 'fr_FR-siwis-medium.onnx'
    config = sherpa_onnx.OfflineTtsConfig(
        model=sherpa_onnx.OfflineTtsModelConfig(
            vits=sherpa_onnx.OfflineTtsVitsModelConfig(
                model=str(model_path), tokens=str(model_dir / 'tokens.txt'),
                data_dir=str(model_dir / 'espeak-ng-data'),
                noise_scale=0.0, noise_scale_w=0.0,
            ),
            provider='cpu', num_threads=2, debug=False,
        ), max_num_sentences=1,
    )
    if not config.validate():
        raise ValueError('Invalid model directory; use the complete Siwis model archive')
    tts = sherpa_onnx.OfflineTts(config)
    track = np.zeros((SR * SECONDS, 2), dtype=np.float64)
    metadata = []
    for index, line in enumerate(LINES, start=1):
        generation = sherpa_onnx.GenerationConfig()
        generation.sid = 0
        generation.speed = line['speed']
        generation.silence_scale = 0.16
        audio = tts.generate(line['spokenText'], generation)
        samples = np.asarray(audio.samples, dtype=np.float64)
        if not len(samples):
            raise ValueError(f"No speech generated: {line['id']}")
        # Trim only outer silence; retain breaths/pauses and pad the word edges.
        audible = np.flatnonzero(np.abs(samples) > max(np.max(np.abs(samples)) * 0.0014, 0.00005))
        left = max(0, int(audible[0]) - round(audio.sample_rate * 0.018))
        right = min(len(samples), int(audible[-1]) + round(audio.sample_rate * 0.045))
        samples = samples[left:right]
        target = out / f'voice-{index:02d}-{line["id"]}.wav'
        with tempfile.TemporaryDirectory(prefix='voice-take-', dir=str(out)) as temp:
            raw = Path(temp) / 'raw.wav'
            sf.write(raw, samples, audio.sample_rate, subtype='PCM_16')
            # Dry, centred voice: modest compression plus R128 normalization.
            # Mono −19 LUFS reads near −16 LUFS after stereo duplication.
            filters = ('highpass=f=85,lowpass=f=10500,'
                       'acompressor=threshold=0.12:ratio=2.4:attack=6:release=95:makeup=1.15,'
                       'loudnorm=I=-19:TP=-4:LRA=5')
            subprocess.run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error',
                            '-i', str(raw), '-af', filters, '-ar', str(SR),
                            '-ac', '1', '-c:a', 'pcm_s16le', str(target)], check=True)
        processed, sample_rate = sf.read(target, dtype='float64')
        duration = len(processed) / sample_rate
        max_duration = line['latestEnd'] - line['start']
        if duration > max_duration:
            # Pitch-preserving speech tightening only when the line exceeds its
            # measured scene window; never crop a spoken word.
            speedup = duration / max_duration
            if speedup > 1.20:
                raise ValueError(f"{line['id']} needs shorter copy ({duration:.3f}s)")
            with tempfile.TemporaryDirectory(prefix='voice-speed-', dir=str(out)) as temp:
                tightened = Path(temp) / 'tightened.wav'
                subprocess.run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error',
                                '-i', str(target), '-af', f'atempo={speedup:.8f}',
                                '-ar', str(SR), '-c:a', 'pcm_s16le', str(tightened)], check=True)
                target.write_bytes(tightened.read_bytes())
            processed, sample_rate = sf.read(target, dtype='float64')
            duration = len(processed) / sample_rate
        start_sample = round(line['start'] * SR)
        track[start_sample:start_sample + len(processed), 0] += processed
        track[start_sample:start_sample + len(processed), 1] += processed
        metadata.append({**line, 'file': target.name, 'duration': round(duration, 6),
                         'end': round(line['start'] + duration, 6),
                         'sourceSampleRate': audio.sample_rate,
                         'sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
    sf.write(out / 'voice-stem.wav', track, SR, subtype='PCM_16')
    source_card = model_dir / 'MODEL_CARD'
    (out / 'SIWIS-MODEL-CARD.txt').write_text(source_card.read_text(), encoding='utf-8')
    details = {
        'provider': 'Local neural TTS, sherpa-onnx 1.13.8 / Piper VITS',
        'voice': 'fr_FR-siwis-medium, female, France French', 'speakerId': 0,
        'duration': SECONDS, 'sampleRate': SR, 'channels': 2,
        'modelSha256': hashlib.sha256(model_path.read_bytes()).hexdigest(),
        'modelSource': 'https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-fr_FR-siwis-medium.tar.bz2',
        'attribution': 'SIWIS French Speech Synthesis Database, University of Edinburgh, CC BY 4.0, https://datashare.is.ed.ac.uk/handle/10283/2353',
        'licenseUrl': 'https://creativecommons.org/licenses/by/4.0/',
        'ttsEngineLicense': 'Apache-2.0 (sherpa-onnx)',
        'renderContract': 'Fixed WAV assets; no voice generation at runtime',
        'takes': metadata,
    }
    (out / 'voice-cues.json').write_text(json.dumps(details, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(details, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model-dir', required=True, type=Path)
    parser.add_argument('--out', type=Path, default=Path(__file__).resolve().parent.parent / 'assets' / 'audio')
    args = parser.parse_args()
    run(args.model_dir, args.out)
