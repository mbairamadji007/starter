# OmniFlow — motion design avec voix off française

Film publicitaire de **15 secondes**, en **1920 × 1080 à 60 images/s**, avec
voix féminine française, musique originale et effets synchronisés. Cette
version applique les références Flowz, ProductHype, Taskip et Wegic fournies
par l’utilisateur : objets en orbite et portail, détails UI en perspective,
rapprochements fonctionnels, grand curseur, réponse immédiate et URL en verre.
L’identité sombre, cyan et émeraude d’OmniFlow reste le fil conducteur.

## Installation, aperçu et export

Prérequis : **Node.js 22 ou supérieur**, npm, **FFmpeg** et FFprobe dans le
`PATH`, ainsi qu’un navigateur Chromium compatible. HyperFrames est fixé à
**0.8.145** et le verrou npm est fourni.

```bash
npm ci
npm run check
npm run preview
npm run render
```

Le fichier final est **`renders/omniflow-voix-off.mp4`** : H.264 avec audio
AAC, 15 secondes, 900 images. Le script utilise `--fps 60`, qualité
`delivery`, CRF 16 et deux workers. Les dimensions et la durée sont déclarées
dans la racine de `index.html` :

```html
data-width="1920" data-height="1080" data-duration="15" data-fps="60"
```

`npm run preview` démarre Studio en arrière-plan ; ouvrir l’URL affichée.
`npm run preview:status` vérifie la session et `npm run preview:stop` l’arrête.
`npm run dev` lance l’aperçu au premier plan. `npm run snapshot` capture les
moments clés, dont le portail, le réseau, l’optimisation et la marque.

La cadence du MP4 est de 60 images/s. La fluidité de l’aperçu et le temps
nécessaire au rendu dépendent du navigateur et du matériel. Sur une machine
avec peu de mémoire :

```bash
npm run render -- --workers 1 --low-memory-mode
```

Pour utiliser un Chromium déjà installé, définir `HYPERFRAMES_BROWSER_PATH`
avec son chemin absolu. Le navigateur charge **GSAP, Inter, les textures et
les WAV localement**. L’installation initiale du CLI et, si nécessaire, du
navigateur demande une connexion ; le modèle vocal ne participe pas au rendu.
Aucune compilation front-end supplémentaire n’est requise.

Contrôler le MP4 :

```bash
ffprobe -v error -show_entries stream=codec_name,width,height,r_frame_rate,nb_frames -show_entries format=duration -of json renders/omniflow-voix-off.mp4
```

## Modules et animation

| Fichier | Rôle |
| --- | --- |
| `index.html` | Calques, fenêtres temporelles, ressources et enregistrement de la timeline |
| `styles/film.css` | Identité visuelle, scène d’alerte, profondeur et atmosphère |
| `styles/product-motion.css` | Traitements du réseau, cadrages fonctionnels et gestes UI |
| `styles/brand-motion.css` | Cube, capsule URL, CTA et pointeur final |
| `components/dashboard.js` / `.css` | Interface de démonstration, KPI, courbe, carte et flux |
| `scenes/01-problem.js` | Alertes, typographie cinétique et transition de sortie |
| `scenes/02-assembly.js` | Assemblage et gros plan sur le réseau temps réel |
| `scenes/03-demo.js` | Travelling, curseur, clic à 10 s et +140 % |
| `scenes/04-brand.js` | Aspiration, logo, URL, essai gratuit et clic final |
| `scenes/master.js` | Construction et coordination des calques et transitions |
| `assets/vendor/motion-blur.js` | Flou d’obturateur des éléments qui traversent vite l’image |
| `assets/audio/` | Masters, stems, prises vocales, repères et attributions |
| `scripts/` | Régénération facultative de la musique, de la voix et du mix |

Les scènes ajoutent leurs animations à **une timeline GSAP en pause**,
enregistrée sur `window.__timelines['omniflow-ad']` une fois construite.
HyperFrames peut demander chaque image à son temps exact. Les mouvements sont
déterministes : les prises vocales et effets sont des WAV préfabriqués, les
particules ont des positions calculées, aucun événement utilisateur ne pilote
la vidéo.

Le portail assure la bascule vers 3,35–4,50 s ; le réseau est mis en avant
vers 6,19–8,43 s. Le clic produit a lieu à 10 s, les chiffres se stabilisent
vers 11,02 s. Le cube et le nom s’assemblent, l’URL apparaît dans sa capsule,
puis le CTA reçoit un clic à 13,30 s. Le tableau détaillé est dans
`STORYBOARD.md` ; les textes et l’identité sont décrits dans `BRIEF.md`.

Après toute modification, exécuter `npm run check`, puis examiner les images
avec `npm run snapshot`. `npm run check -- --snapshots` ajoute les captures
annotées. Le contrôle couvre les ressources, le runtime, la mise en page,
la motion déclarée et le contraste. Les données de l’interface sont des
valeurs de démonstration.

## Voix et synchronisation sonore

**`assets/audio/voice-master.wav`** est le master intégré au film : 15,000 s,
stéréo 48 kHz / PCM 16 bits, **−16,00 LUFS**, **−2,14 dBTP**, LRA **2,8 LU**.
Il est placé une seule fois dans `index.html`, avec `id="omniflow-sound"`,
`data-start="0"` et `data-duration="15"`. HyperFrames contrôle sa lecture.
Le master `sound-bed.wav` conserve la version musicale et effets sans voix.

| Fenêtre vocale | Phrase |
| --- | --- |
| 0,350–1,913 s | Votre logistique vous échappe ? |
| 4,250–7,416 s | OmniFlow. Un seul dashboard. Zéro latence. |
| 9,150–11,004 s | Plus cent quarante pour cent d’efficacité. |
| 13,000–14,388 s | Démarrez votre essai gratuit. |

La voix française **Siwis medium** est synthétisée localement avec
**sherpa-onnx 1.13.8 / Piper VITS**. La source vocale à **22,05 kHz** est
rééchantillonnée à 48 kHz. Les débits et repères sont enregistrés dans
`assets/audio/voice-cues.json` ; les mesures finales sont dans
`assets/audio/voice-mix.json`. La musique à 120 BPM et les effets gardent
leur dynamique, avec un espace de fréquence et de niveau laissé aux phrases.

`voice-stem.wav` aligne les quatre prises sur les 15 s. Les prises séparées
`voice-01-question.wav` à `voice-04-essai.wav` permettent de changer un passage.
Les stems originaux de musique, transitions, UI et logo restent fournis.
La procédure de remplacement, le ducking et les stems du mix sont décrits
dans **`SOUND_DESIGN.md`**. Éviter de superposer le master complet à ses stems.

Toutes les pistes sont déjà livrées ; aucune synthèse vocale n’est nécessaire
pour vérifier, prévisualiser ou exporter. Pour reconstruire la musique et le
mix à partir de la voix fournie, Python 3, NumPy et FFmpeg suffisent :

```bash
npm run audio:build
```

Pour régénérer la narration, installer en plus `sherpa-onnx==1.13.8` et
`soundfile`, puis télécharger et extraire le modèle indiqué dans `NOTICE.md`.
Le modèle doit rester dans un répertoire de travail externe au paquet source :

```bash
npm run audio:voice -- --model-dir /chemin/vers/vits-piper-fr_FR-siwis-medium
npm run audio:mix
```

`npm run audio:music` reconstruit uniquement la musique et les effets.
`npm run audio:mix` reconstruit uniquement le master avec les prises existantes.
Les attributions sont dans **`NOTICE.md`** et
`assets/audio/SIWIS-MODEL-CARD.txt` ; Inter conserve sa licence OFL et les
bibliothèques leurs notices d’origine.
