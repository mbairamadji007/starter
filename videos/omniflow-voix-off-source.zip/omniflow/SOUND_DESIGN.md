# OmniFlow V2 — voix française et synchronisation sonore

La bande originale est livrée avec une **voix française neuronale**,
et synchronisée à **120 BPM** :
une noire toutes les **0,5 s**, une croche toutes les **0,25 s**. Les transitions
principales à 0, 4, 9 et 12 secondes sont donc sur la grille musicale.

`assets/audio/voice-master.wav` est le mix final stéréo de **15,000 s**,
**48 kHz / PCM 16 bits**. Mesure EBU R128 : **−16,00 LUFS intégrés**,
**−2,14 dBTP**, plage de dynamique **2,8 LU**. La voix est sèche et centrée.
La musique s'atténue de 9,6 dB pendant les phrases ; trois réductions spectrales
à 350, 1 600 et 2 800 Hz dégagent la zone d'intelligibilité. Les effets reçoivent
une atténuation plus légère de 6,4 dB. Une anticipation de 100 ms et un retour
de 250 ms rendent les changements de niveau souples.

`sound-bed.wav` reste la version musicale originale sans voix. Le rendu utilise
le master parlé. Les WAV sont déjà calculés : la voix ne sollicite aucun modèle
pendant l'export vidéo.

## Texte réellement prononcé

Les durées ci-dessous proviennent des prises générées ; aucune phrase n'est
coupée pour entrer dans son segment.

| Début | Fin | Texte |
| --- | --- | --- |
| 0,350 s | 1,913 s | Votre logistique vous échappe ? |
| 4,250 s | 7,416 s | OmniFlow. Un seul dashboard. Zéro latence. |
| 9,150 s | 11,004 s | Plus cent quarante pour cent d'efficacité. |
| 13,000 s | 14,388 s | Démarrez votre essai gratuit. |

La prise de marque utilise l'orthographe phonétique « Omni Flo » afin de
prononcer OmniFlow en français. « Cent quarante pour cent » est écrit en toutes
lettres dans le texte envoyé au modèle. La dernière phrase laisse 612 ms de
maintien visuel après la voix.

## Intégration HyperFrames

Le master doit être placé une seule fois, dans la composition principale :

```html
<audio
  id="omniflow-sound"
  src="assets/audio/voice-master.wav"
  data-start="0"
  data-duration="15"
  data-track-index="8"
  data-volume="1"
  data-label="OmniFlow V2 · voix FR + bande originale"
></audio>
```

HyperFrames pilote la lecture et le rendu. La synchronisation dépend des attributs
de la composition : aucun `autoplay`, timer JavaScript ou appel Web Audio n'est
nécessaire. L'ID permet au moteur d'identifier la piste lors du mixage.

## Repères image / son

Le temps en secondes est la référence précise. La colonne image donne l'image
la plus proche pour un export à 60 FPS.

| Temps | Image 60 FPS | Son | Geste visuel associé |
| --- | ---: | --- | --- |
| 0,00 s | 0 | Air stéréo + chute de sub-bass | Zoom dans les alertes |
| 0,18–2,14 s | 11–128 | Impacts UI brefs | Widgets fragmentés et punchline |
| 3,58 s | 215 | Montée de 420 ms | Anticipation de la bascule |
| **4,00 s** | **240** | **Whoosh + sub drop** | **Bascule du portail / assemblage OmniFlow** |
| 4,18–5,75 s | 251–345 | Clics d'assemblage | Cartes KPI, graphique, flux |
| 8,62 s | 517 | Montée de 380 ms | Départ du travelling |
| **9,00 s** | **540** | **Whoosh + sub drop** | **Mockup flottant** |
| **10,00 s** | **600** | **Clic précis** | **Déclenchement du compteur** |
| 10,18 s | 611 | Carillon court | Onde émeraude autour du clic |
| 10,20–10,64 s | 612–638 | Micro-clics accélérés | Défilement des chiffres |
| 10,78 s | 647 | Note de succès | Dernière accélération du compteur vers +140 % |
| 11,55 s | 693 | Montée de 450 ms | Aspiration des calques |
| **12,00 s** | **720** | **Whoosh + sub drop** | **Rassemblement central** |
| **12,35 s** | **741** | **Accord logo + impact grave** | **Accent du cube et assemblage du logo** |
| **13,15 s** | **789** | **Tick clair et note courte** | **Accent sonore du CTA en cours de révélation** |
| **13,30 s** | **798** | **Clic discret ajouté en V2** | **Curseur sur le CTA** |
| 14,30–15,00 s | 858–900 | Sortie douce | Maintien du logo et de l'URL |

Le fichier `assets/audio/cues.json` contient les repères de la musique originale.
`voice-cues.json` documente les prises, les plages réelles de voix, le modèle et
son empreinte. `voice-mix.json` documente les mesures du master parlé et le mixage.

## Remplacer les sons ou retravailler le mix

Les stems stéréo de 15 s sont fournis, tous alignés au temps 0 :

| Fichier | Contenu |
| --- | --- |
| `music-stem.wav` | Pulsation 120 BPM, basse, arpège, nappe harmonique |
| `transitions-stem.wav` | Whooshes, anticipations, sub drops à 0 / 4 / 9 / 12 s |
| `ui-stem.wav` | Clics, assemblage, compteur, succès |
| `logo-stem.wav` | Aspiration finale, accord du logo, tick du CTA |
| `voice-stem.wav` | Voix seule, avant le gain du master final |
| `ducked-background.wav` | Musique et effets après carve / ducking / gain final |
| `voice-mix-stem.wav` | Voix seule, avec le gain du master final |

Pour retrouver le master final dans HyperFrames, remplacer l'élément master par
**deux pistes** : `ducked-background.wav` et `voice-mix-stem.wav`. Donner à
chacune un ID unique, `data-start="0"` et `data-duration="15"`.
La somme de ces deux pistes reproduit le master à l'arrondi PCM près.

Pour reprendre tout le mixage, placer les quatre stems de musique / effets et
`voice-stem.wav` dans cinq
éléments `<audio>` avec des IDs uniques, `data-start="0"`, `data-duration="15"`
et une piste distincte pour chacun. Dans ce cas, refaire le carve et le ducking
de la musique sous la voix. Les prises séparées `voice-01-question.wav` à
`voice-04-essai.wav` permettent de déplacer chaque phrase indépendamment.

Pour utiliser une bibliothèque sonore d'agence, conserver `music-stem.wav`, puis
remplacer les autres stems par les nouveaux effets. Placer les impacts exactement
à **4 / 9 / 12 s**, le clic à **10 s**, le logo à **12,35 s** et le tick CTA à
**13,15 s**, puis le clic final à **13,30 s**. Un whoosh qui prépare un impact commence 350–450 ms avant ce repère ;
son sommet doit coïncider avec le flash. Préserver environ 2 dB de marge en crête
dans le nouveau master, puis refaire une mesure EBU R128.

## Régénérer à l'identique

Depuis la racine du projet, avec Python 3, NumPy et FFmpeg installés :

```bash
python3 scripts/generate_audio.py
python3 scripts/mix_voice.py
```

Le script de musique ne télécharge aucun échantillon : oscillateurs, bruit filtré,
enveloppes et espace stéréo sont synthétisés localement. Une graine fixe rend
les WAV reproductibles. FFmpeg mesure le niveau EBU R128 ; un gain constant
vise −16 LUFS et respecte le plafond de −1,8 dBTP, sans écraser les impacts.
Le niveau final peut rester légèrement sous la cible pour conserver cette marge.
`mix_voice.py` remet ensuite les prises parlées existantes dans le master V2,
recalcule le carve / ducking et vérifie le niveau.

Pour produire les mêmes fichiers dans un autre répertoire :

```bash
python3 scripts/generate_audio.py --out assets/audio
```

## Régénérer la voix neuronale

Le rendu fonctionne avec les WAV fournis. Pour régénérer la voix, installer
Python 3, `sherpa-onnx==1.13.8`, `numpy` et `soundfile`, ainsi que FFmpeg.
Télécharger puis extraire le modèle officiel :

<https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-fr_FR-siwis-medium.tar.bz2>

Exécuter :

```bash
python3 scripts/generate_voice.py --model-dir /chemin/vits-piper-fr_FR-siwis-medium
python3 scripts/mix_voice.py
```

Le modèle Siwis produit une voix féminine française à 22 050 Hz ; les prises sont
filtrées, légèrement compressées puis converties en WAV à 48 000 Hz. La voix
du master est dupliquée au centre des deux canaux. Les paramètres VITS de bruit
sont fixés à zéro pour conserver des prises reproductibles.

Attribution de la source vocale : **SIWIS French Speech Synthesis Database,
University of Edinburgh**, jeu de données sous **CC BY 4.0**.
Source : <https://datashare.is.ed.ac.uk/handle/10283/2353>.
Licence : <https://creativecommons.org/licenses/by/4.0/>.
La carte fournie avec le modèle est copiée dans `assets/audio/SIWIS-MODEL-CARD.txt`.
Le moteur sherpa-onnx est distribué sous Apache 2.0.
