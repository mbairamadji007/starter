# Découpage — OmniFlow, version avec voix off

| Temps | Image et mouvement | Texte / voix off | Son |
| --- | --- | --- | --- |
| 0–3,35 s | Zoom dans les widgets d’alerte, cartes déconnectées en perspective, punchline révélée par groupes de mots | « Votre logistique vous échappe ? » | Voix à 0,350–1,913 s, impact et pulsation |
| 3,35–4,50 s | Les éléments s’aspirent dans une sphère/portail ; la géométrie relie le chaos au dashboard | OmniFlow | Montée, whoosh et impact de bascule à 4 s |
| 4–6,19 s | Assemblage de l’interface, cartes KPI détachées du plan, courbe et flux connectés | « OmniFlow. Un seul dashboard. Zéro latence. » | Voix à 4,250–7,416 s, ticks d’assemblage |
| 6,19–8,43 s | Rapprochement sur le réseau temps réel ; routes et conteneurs s’éclairent, indicateurs répondent | Mise en évidence du réseau et de la synchronisation | Micro-effets UI, musique sous la narration |
| 8,43–9 s | Retour au cadrage produit et rotation vers le mockup flottant | Transition vers l’action | Whoosh de travelling |
| 9–12 s | Caméra autour de l’écran, grand curseur, clic à 10 s, métriques roulantes ; +140 % stabilisé vers 11,02 s | « Plus cent quarante pour cent d’efficacité. » | Voix à 9,150–11,004 s, clic et confirmations |
| 11,86–12,91 s | Aspiration centrale, cube lumineux puis assemblage du logo et révélation du nom | OmniFlow | Accord et impact du logo |
| 12,69–13,30 s | Capsule URL et texte révélés, CTA à 13,00–13,28 s, clic du pointeur à 13,30 s | omniflow.io / « Démarrez votre essai gratuit. » | Voix à 13,000–14,388 s, tick et onde du clic |
| 13,40–15 s | Logo, URL et CTA maintenus, respiration lumineuse discrète | DÉMARRER L’ESSAI GRATUIT | Fin de la phrase et sortie progressive |

Les fenêtres principales restent 0–4, 4–9, 9–12 et 12–15 secondes. Les
chevauchements aux limites assurent la continuité spatiale sans allonger le
film. Le découpage conserve des moments de lecture après les mouvements.
La géométrie fait les transitions ; le curseur montre l’action et sa réponse.

Les repères vocaux exacts sont dans `assets/audio/voice-cues.json` ; les
repères de musique et d’effets sont dans `assets/audio/cues.json`. Les valeurs
du dashboard sont des données de démonstration. La scène de marque reste
visible jusqu’à la dernière image.
