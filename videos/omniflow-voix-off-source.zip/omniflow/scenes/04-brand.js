/* Outro : les fragments produit deviennent le cube, puis la marque.
 * Tous les mouvements utilisent le temps absolu de la composition. */
window.OmniScenes = window.OmniScenes || {};
window.OmniScenes.brand = (tl) => {
  tl.addLabel('brand', 12).addLabel('logo', 12.35).addLabel('cta', 13.30);
  tl.fromTo('.brand-inner', {opacity:0}, {opacity:1, duration:.12}, 11.85);

  document.querySelectorAll('.suction-chip').forEach((chip, i) => {
    const angle = i * Math.PI / 5 + .22;
    const radius = 780 + (i % 3) * 64;
    const orbitAngle = angle + .42;
    const entry = 11.86 + i * .009;
    // Les fragments viennent volontairement de l'extérieur du cadrage.
    chip.setAttribute('data-layout-allow-overflow', '');
    chip.setAttribute('data-layout-allow-overlap', '');
    chip.setAttribute('data-layout-allow-occlusion', '');
    tl.fromTo(chip,
      {x:Math.cos(angle)*radius, y:Math.sin(angle)*radius*.64-26,
        z:150, rotationZ:i*29-18, rotationY:i%2?34:-34, scale:1.08, opacity:0},
      {x:Math.cos(orbitAngle)*radius*.54, y:Math.sin(orbitAngle)*radius*.38-40,
        z:60, rotationZ:i*29+20, rotationY:0, scale:.82, opacity:.93,
        duration:.19, ease:'power2.out'}, entry);
    tl.to(chip,
      {x:0, y:-82, z:-150, rotationZ:i*29+115, rotationY:65,
        scale:.035, opacity:0, duration:.31, ease:'power4.in'}, entry+.19);
  });

  tl.fromTo('.brand-aura', {scale:.48, opacity:0},
    {scale:1, opacity:1, duration:.72, ease:'power3.out'}, 12.06);

  // Le cube naît au point de convergence, puis glisse dans le lockup.
  // Calibrage unique après document.fonts.ready : le centre reste exact même
  // si la police locale a une largeur de mot légèrement différente.
  const logo = document.querySelector('.brand-logo');
  const logoBox = logo.getBoundingClientRect();
  const sceneBox = document.querySelector('.brand-inner').getBoundingClientRect();
  const canvasScale = sceneBox.width / 1920 || 1;
  const cubeStartX = 960 - (logoBox.left + logoBox.width / 2 - sceneBox.left) / canvasScale;
  tl.fromTo('.brand-logo',
    {x:cubeStartX, y:62, scale:.38, rotationY:78, rotationZ:-16, opacity:0},
    {x:cubeStartX, y:0, scale:1.06, rotationY:0, rotationZ:0, opacity:1,
      duration:.39, ease:'back.out(1.35)'}, 12.12);
  tl.to('.brand-logo', {x:0, scale:1, duration:.36, ease:'power3.inOut'}, 12.48);
  tl.fromTo('.brand-logo',
    {filter:'drop-shadow(0 0 32px #00F2FEBB) drop-shadow(0 0 72px #4FACFE55)'},
    {filter:'drop-shadow(0 0 16px #00F2FE66) drop-shadow(0 12px 24px #00000088)',
      duration:.67, ease:'power2.out'}, 12.33);
  tl.fromTo('.brand-name',
    {x:90, y:15, opacity:0, clipPath:'inset(0 100% 0 0)'},
    {x:0, y:0, opacity:1, clipPath:'inset(0 0% 0 0)',
      duration:.37, ease:'power4.out'}, 12.54);
  document.querySelector('.brand-name').setAttribute('data-layout-allow-occlusion', '');
  tl.fromTo('.brand-intro', {y:18, opacity:0},
    {y:0, opacity:1, duration:.32, ease:'power3.out'}, 12.50);
  tl.fromTo('.logo-spark', {x:-520, scale:0, opacity:0},
    {x:-160, scale:1.2, opacity:.9, duration:.19, ease:'power2.out'}, 12.60);
  tl.to('.logo-spark', {x:140, scale:0, opacity:0, duration:.28, ease:'power2.in'}, 12.79);

  // Capsule Taskip : la surface arrive, puis l'adresse se révèle à l'intérieur.
  tl.fromTo('.brand-url', {y:23, scale:.9, opacity:0},
    {y:0, scale:1, opacity:1, duration:.29, ease:'back.out(1.1)'}, 12.69);
  tl.fromTo('.brand-url-text', {clipPath:'inset(0 100% 0 0)'},
    {clipPath:'inset(0 0% 0 0)', duration:.36, ease:'none'}, 12.84);
  const urlText = document.querySelector('.brand-url-text');
  if (urlText) urlText.setAttribute('data-layout-allow-occlusion', '');
  tl.fromTo('.brand-url-caret', {opacity:0},
    {opacity:.9, duration:.08, ease:'none'}, 12.91);
  tl.to('.brand-url-caret', {opacity:0, duration:.10}, 13.21);

  tl.fromTo('.cta-wrap', {y:38, scale:.93, opacity:0},
    {y:0, scale:1, opacity:1, duration:.28, ease:'back.out(1.15)'}, 13.00);
  tl.fromTo('.brand-cursor', {x:1480, y:896, scale:1.15, opacity:0},
    {x:1195, y:708, scale:1, opacity:1, duration:.32, ease:'power3.inOut'}, 12.98);
  tl.to('.brand-cursor', {scale:.82, duration:.05, ease:'power2.in'}, 13.30);
  tl.to('.brand-cursor', {scale:1, duration:.08, ease:'back.out(1.2)'}, 13.35);
  tl.to('.brand-cursor', {x:1248, y:765, opacity:0, duration:.17, ease:'power2.in'}, 13.43);
  tl.to('.cta-button', {scale:.988, duration:.04, ease:'power2.in'}, 13.30);
  tl.to('.cta-button', {scale:1, duration:.07, ease:'power3.out'}, 13.34);
  tl.fromTo('.brand-click-ring', {scale:.12, opacity:.95},
    {scale:5.6, opacity:0, duration:.42, ease:'power3.out', immediateRender:false}, 13.30);
  tl.fromTo('.cta-halo', {scale:.98, opacity:0},
    {scale:1.04, opacity:.58, duration:.48, repeat:2, yoyo:true, ease:'sine.inOut'}, 13.34);
  tl.fromTo('.brand-promise', {y:12, opacity:0},
    {y:0, opacity:1, duration:.26, ease:'power3.out'}, 13.10);

  // Les mots, l'adresse et le bouton restent fixes pour la lecture finale.
  tl.to('.brand-aura', {scale:1.045, duration:1.5, ease:'sine.inOut'}, 13.50);
};
