/* Composition déterministe : aucune horloge, aucun événement utilisateur,
 * aucun appel réseau. HyperFrames possède la lecture et le seek des médias. */
window.buildOmniFlow = (tl) => {
  document.querySelector('.corner-mark').innerHTML=window.OmniUI.brand;
  document.querySelector('.portal-mark').innerHTML=window.OmniUI.brand;
  document.getElementById('assembly-dashboard').innerHTML = window.OmniUI.renderDashboard({prefix:'assembly'});
  document.getElementById('demo-dashboard').innerHTML = window.OmniUI.renderDashboard({prefix:'demo'});
  document.querySelector('#demo-dashboard .efficiency-value').innerHTML='+<span class="ui-efficiency-number">0</span><span class="kpi-unit">%</span>';
  // Les reflets débordent volontairement à l'intérieur des masques d'écran.
  document.querySelectorAll('.screen-shine').forEach(el=>el.setAttribute('data-layout-allow-overflow',''));
  for (const id of ['digit-hundreds','digit-tens','digit-units']) {
    const strip = document.getElementById(id);
    for (let i=0;i<30;i++) {
      const row=document.createElement('span');row.textContent=String(i%10);
      // Les chiffres voisins sont masqués par la fenêtre mécanique de 160 px.
      row.setAttribute('data-layout-allow-overlap','');
      row.setAttribute('data-layout-allow-occlusion','');
      strip.appendChild(row);
    }
  }
  const particles=document.getElementById('particles');
  for(let i=0;i<28;i++) {const p=document.createElement('i');p.className='particle';p.style.left=`${(i*317+131)%1880+20}px`;p.style.top=`${(i*197+59)%980+40}px`;particles.appendChild(p);}
  const suction=document.getElementById('suction-field');
  for(let i=0;i<10;i++){const chip=document.createElement('i');chip.className='suction-chip';suction.appendChild(chip);}
    tl.fromTo('.corner-content',{opacity:0,y:-12},{opacity:1,y:0,duration:.48},.12);
    tl.fromTo('.aura-cyan',{x:-30,y:30},{x:100,y:-35,duration:15,ease:'sine.inOut'},0);
    tl.fromTo('.aura-blue',{x:40,y:-20},{x:-100,y:65,duration:15,ease:'sine.inOut'},0);
    document.querySelectorAll('.particle').forEach((p,i)=>{tl.fromTo(p,{y:0,opacity:.12+(i%4)*.06},{y:-35-(i%5)*13,opacity:.21+(i%3)*.08,duration:15,ease:'sine.inOut'},0);});
    // Un objet lumineux relie spatialement le problème à l'interface.
    tl.fromTo('.portal-stage',{scale:.16,rotationX:55,rotationY:-35,rotationZ:-25,opacity:0},
      {scale:1,rotationX:8,rotationY:12,rotationZ:0,opacity:1,duration:.55,ease:'back.out(1.35)'},3.34);
    tl.fromTo('.portal-ring',{rotationZ:-60},{rotationZ:115,duration:1.28,ease:'sine.inOut'},3.34);
    tl.fromTo('.portal-mark',{z:8,scale:.4,opacity:0,rotationY:40},
      {z:8,scale:1,opacity:1,rotationY:0,duration:.32,ease:'back.out(1.4)'},3.59);
    tl.fromTo('.portal-label',{y:15,opacity:0},{y:0,opacity:1,duration:.23},3.65);
    tl.to('.portal-label',{opacity:0,duration:.09},3.98);
    tl.to('.portal-mark',{scale:.5,opacity:0,duration:.2,ease:'power2.in'},4.0);
    tl.to('.portal-ring-inner',{opacity:0,duration:.18},4.03);
    tl.to('.portal-stage',{scale:7.5,rotationX:0,rotationY:0,opacity:0,
      duration:.62,ease:'power3.in'},4.04);
    tl.to('.portal-orbit',{scale:1.22,duration:.55,ease:'power2.in'},4.04);
    window.OmniScenes.problem(tl);window.OmniScenes.assembly(tl);window.OmniScenes.demo(tl);window.OmniScenes.brand(tl);
    const transition=(at,strength=1)=>{
      tl.fromTo('.flash-wash',{opacity:0},{opacity:.9*strength,duration:.045,ease:'none',immediateRender:false},at);
      tl.to('.flash-wash',{opacity:0,duration:.16,ease:'power2.out'},at+.045);
      tl.fromTo('.glitch-bars',{opacity:0,x:-100,scaleX:.7},{opacity:.9*strength,x:30,scaleX:1,duration:.05,ease:'none',immediateRender:false},at-.075);
      tl.to('.glitch-bars',{x:110,opacity:0,duration:.11,ease:'power3.in'},at+.03);
      tl.fromTo('.transition-slash',{x:-100,skewX:-25,opacity:.8*strength},{x:2300,opacity:0,duration:.24,ease:'power2.in',immediateRender:false},at-.08);
    };
    transition(3.995,.68);transition(8.995,.28);transition(12.21,.4);
    return tl;
};
