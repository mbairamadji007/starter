window.OmniScenes = window.OmniScenes || {};
window.OmniScenes.problem = (tl) => {
  tl.addLabel('problem',0).addLabel('convergence',3.35);
  tl.fromTo('.problem-camera',{scale:1.48,rotationZ:-7,z:180},
    {scale:1,rotationZ:0,z:0,duration:.7,ease:'power4.out'},0);
  const cards=['.alert-stock','.alert-delay','.alert-network','.alert-capacity'];
  const start=[{x:-235,y:-165,rotationZ:-21,rotationY:24},
    {x:230,y:-75,rotationZ:20,rotationY:-24},
    {x:-125,y:130,rotationZ:14,rotationY:18},
    {x:170,y:150,rotationZ:-15,rotationY:-18}];
  const convergence=[{x:650,y:258},{x:-655,y:205},{x:538,y:-289},{x:-563,y:-303}];
  cards.forEach((selector,i)=>{
    tl.fromTo(selector,{...start[i],scale:.88,opacity:.6},
      {x:0,y:0,rotationZ:i%2?5:-6,rotationY:i%2?-5:7,scale:1,opacity:1,
       duration:.55,ease:'back.out(1.3)'},.02+i*.055);
    if(i>1)tl.fromTo(selector,{filter:'blur(8px)'},{filter:'blur(0px)',duration:.24},.02+i*.055);
    tl.to(selector,{x:i%2?-30:30,y:i%2?-18:22,rotationZ:i%2?1:-2,
      rotationY:i%2?8:-5,duration:1.15,ease:'sine.inOut'},.9+i*.06);
    tl.to(selector,{x:i%2?18:-18,y:i%2?12:-10,rotationZ:i%2?5:-6,
      duration:.95,ease:'sine.inOut'},2.1+i*.035);
    // Trajectoires individuelles, convergence dans un même objet central.
    tl.to(selector,{...convergence[i],scale:.11,z:-420,rotationZ:i%2?-92:92,
      rotationY:i%2?65:-65,opacity:0,duration:.48,ease:'power4.in'},3.31+i*.035);
  });
  tl.fromTo('.disconnected-label',{y:-40,opacity:0},{y:0,opacity:1,duration:.3},.2);
  tl.fromTo('.problem-eyebrow',{y:22,opacity:0},{y:0,opacity:1,duration:.32},.23);
  const words=['.word-votre','.word-logistique','.word-vous','.word-echappe'];
  words.forEach((word,i)=>{
    tl.fromTo(word,{yPercent:115,rotationX:-28,skewY:3,opacity:0},
      {yPercent:0,rotationX:0,skewY:0,opacity:1,duration:.44,ease:'power4.out'},.32+i*.13);
  });
  tl.fromTo('.question-mark',{y:80,scale:1.8,rotationZ:20,opacity:0},
    {y:0,scale:1,rotationZ:0,opacity:1,duration:.5,ease:'back.out(2.1)'},.78);
  tl.fromTo('.problem-subline span',{y:23,opacity:0},{y:0,opacity:1,
    duration:.34,stagger:.09},1.02);
  tl.fromTo('.problem-scan',{x:-35,opacity:0},{x:0,opacity:1,duration:.4},1.25);
  tl.to('.alert-card-top .alert-dot',{opacity:.35,duration:.12,repeat:5,yoyo:true,ease:'none'},1.6);
  tl.to('.problem-copy',{scale:1.035,duration:1.7,ease:'none'},1.5);
  tl.to('.problem-copy',{scale:.72,z:-300,rotationX:18,y:-65,opacity:0,
    duration:.38,ease:'power4.in'},3.2);
  tl.to(['.disconnected-label','.problem-scan','.broken-connections'],
    {opacity:0,duration:.2,ease:'power2.in'},3.28);
  tl.to('.problem-red-glow',{opacity:0,duration:.35},3.35);
  tl.to('.problem-camera',{opacity:0,duration:.11},3.93);
};
