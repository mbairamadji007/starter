/* V2: travel into the active action, click, visibly resolve the product. */
window.OmniScenes = window.OmniScenes || {};
window.OmniScenes.demo = (tl) => {
  const scene=document.querySelector('.demo-inner');
  if(!scene.querySelector('.optimization-toast')){
    const toast=document.createElement('div');toast.className='optimization-toast';
    toast.innerHTML='<span class="optimization-toast-icon">✓</span><span><strong>12 flux réacheminés.</strong> Réseau synchronisé.</span><span class="toast-ai">OMNIFLOW AI</span>';
    scene.appendChild(toast);
  }
  const button=document.querySelector('#demo-dashboard .optimize-button');
  if(!button.querySelector('.optimization-button-success')){
    const success=document.createElement('span');success.className='optimization-button-success';success.innerHTML=`${window.OmniUI.icon('check')} Flux optimisés`;button.appendChild(success);
  }
  // Fixed design coordinates on the intrinsic 1400 × 760 dashboard.
  const clickX=1254,clickY=130;
  const ring=document.querySelector('.click-ring'),wave=document.querySelector('.optimization-wave');
  ring.style.left=`${clickX-14}px`;ring.style.top=`${clickY-14}px`;wave.style.left=`${clickX-28}px`;wave.style.top=`${clickY-28}px`;
  tl.addLabel('demo',9).addLabel('click',10);
  tl.fromTo('.demo-inner',{opacity:0},{opacity:1,duration:.13},9);
  tl.fromTo('.demo-label',{x:-28,y:10,opacity:0},{x:0,y:0,opacity:1,duration:.36,ease:'power3.out'},9.04);
  tl.fromTo('.floating-device',{x:0,y:0,z:0,scale:.82,rotationX:5,rotationY:-8,rotationZ:-2,opacity:1},{x:-150,y:-29,z:75,scale:.89,rotationX:8,rotationY:-18,rotationZ:-2.3,opacity:1,duration:.78,ease:'power3.inOut'},9);
  tl.fromTo('.demo-shine',{x:-1150},{x:900,duration:.9,ease:'power2.inOut'},9.1);
  // Cursor is inside the moving screen, so the click follows the camera pose.
  tl.fromTo('.cursor',{x:1055,y:550,scale:1.6,rotation:-8,opacity:0},{x:clickX-5,y:clickY-4,scale:1.38,rotation:0,opacity:1,duration:.61,ease:'power3.inOut'},9.32);
  tl.to('#demo-dashboard .optimize-button',{boxShadow:'0 0 0 3px rgba(0,242,254,.2),0 7px 26px rgba(0,242,254,.24)',duration:.18},9.85);
  tl.to('.cursor',{scale:1.05,duration:.07,ease:'power2.in'},10);
  tl.to('.cursor',{scale:1.38,duration:.13,ease:'back.out(2)'},10.07);
  tl.fromTo('.click-ring',{scale:.2,opacity:1},{scale:4.1,opacity:0,duration:.41,ease:'power2.out'},10);
  tl.fromTo('.optimization-wave',{scale:.1,opacity:.66},{scale:28,opacity:0,duration:.73,ease:'power3.out'},10.025);
  tl.to('#demo-dashboard .optimize-button',{backgroundImage:'linear-gradient(125deg,#00F5A0,#60F6C4)',duration:.14},10.03);
  tl.fromTo('.optimization-button-success',{opacity:0,y:5},{opacity:1,y:0,duration:.18,ease:'power3.out'},10.035);
  tl.to('#demo-dashboard .optimize-button > span:not(.optimization-button-success)',{opacity:0,duration:.12},10.035);
  tl.to('#demo-dashboard .route-line',{stroke:'#00F5A0',duration:.25,stagger:.035},10.04);
  tl.to('#demo-dashboard .route-node',{fill:'#00F5A0',duration:.2,stagger:.025},10.08);
  tl.to('#demo-dashboard .route-node',{scale:1.35,transformOrigin:'50% 50%',duration:.13,repeat:1,yoyo:true,stagger:.025,ease:'power2.out'},10.14);
  tl.fromTo('.optimization-toast',{x:60,y:-17,scale:.9,opacity:0},{x:0,y:0,scale:1,opacity:1,duration:.38,ease:'back.out(1.25)'},10.06);
  // These two minor controls yield their space to the detached outcome card.
  tl.to(['#demo-dashboard .performance-panel .panel-heading > span','#demo-dashboard .shipments-panel .panel-heading > span'],{opacity:0,duration:.1},10.18);
  // Action creates the outcome; the device travels into a split composition.
  tl.to('.floating-device',{x:-285,y:46,z:-95,scale:.7,rotationX:4,rotationY:16,rotationZ:-2,duration:.64,ease:'power3.inOut'},10.15);
  tl.to('#demo-dashboard .performance-panel',{opacity:.12,duration:.2},10.2);
  tl.fromTo('.efficiency-callout',{x:55,y:-125,z:-170,scale:.28,rotationX:12,rotationY:-32,rotationZ:-5,opacity:0},{x:0,y:0,z:0,scale:1,rotationX:0,rotationY:0,rotationZ:0,opacity:1,duration:.58,ease:'expo.out'},10.08);
  tl.fromTo('.efficiency-status',{y:10,opacity:0},{y:0,opacity:1,duration:.25,ease:'power3.out'},10.29);
  tl.fromTo('#digit-hundreds',{y:0},{y:-3360,duration:.67,ease:'power4.out'},10.13);
  tl.fromTo('#digit-tens',{y:0},{y:-3840,duration:.78,ease:'power4.out'},10.13);
  tl.fromTo('#digit-units',{y:0},{y:-3200,duration:.89,ease:'power4.out'},10.13);
  tl.fromTo('.ui-efficiency-number',{textContent:0},{textContent:140,snap:{textContent:1},duration:.89,ease:'power4.out'},10.13);
  tl.fromTo('.efficiency-underline',{scaleX:0},{scaleX:1,duration:.44,ease:'power3.out'},10.59);
  tl.to('.cursor',{x:clickX+40,y:clickY+52,opacity:0,duration:.3,ease:'power2.in'},10.42);
  tl.to('.floating-device',{rotationY:11,rotationX:2,y:39,duration:1.02,ease:'sine.inOut'},10.79);
  tl.to('.efficiency-callout',{y:-4,duration:.75,ease:'sine.inOut'},11.03);
  // +140% is settled at 11.02 and held until the brand suction at 11.89.
  tl.to('.floating-device',{x:425,y:-30,z:-760,scale:.08,rotationZ:19,opacity:0,duration:.35,ease:'power4.in'},11.89);
  tl.to('.efficiency-callout',{x:-135,y:-195,z:-550,scale:.1,rotationZ:-9,opacity:0,duration:.35,ease:'power4.in'},11.89);
  tl.to('.optimization-toast',{x:-95,y:-130,scale:.25,opacity:0,duration:.28,ease:'power3.in'},11.9);
  tl.to('.demo-label',{opacity:0,y:-18,duration:.19},11.93);
};
