/* V2: portal → product assembly → a detached spatial network detail.
 * All movement belongs to the parent seekable timeline at absolute times. */
window.OmniScenes = window.OmniScenes || {};
window.OmniScenes.assembly = (tl) => {
  const scene = document.querySelector('.assembly-inner');
  if (!scene.querySelector('.network-focus')) {
    const feature = document.createElement('div');
    feature.className = 'network-focus';
    feature.setAttribute('aria-label', 'Réseau de conteneurs connecté en temps réel');
    const source = document.querySelector('#assembly-dashboard .route-map');
    const map = source.outerHTML.replaceAll('assembly-', 'focus-');
    feature.innerHTML = `<div class="network-focus-rim"></div>
      <div class="focus-heading"><div class="focus-title"><span class="focus-heading-icon">${window.OmniUI.icon('globe')}</span><span>42 pays. Un seul flux.</span></div><div class="focus-live"><i></i>TEMPS RÉEL</div></div>
      <div class="focus-map">${map}</div>
      <div class="focus-insight"><div class="focus-insight-eyebrow">SYNCHRONISATION</div><div class="focus-speed">8<span>ms</span></div><div class="focus-speed-description">Chaque mouvement.<span>Instantanément visible.</span></div><div class="focus-route-card"><div class="focus-route-code"><i></i> CONTENEUR OF–2048</div><div class="focus-route-destination">Rotterdam<span>→</span>Singapour</div><div class="focus-route-success">${window.OmniUI.icon('check')}Trajet optimisé</div></div></div>
      <div class="focus-bottom"><span><i></i>FLUX CONNECTÉS</span><span>Stocks · Transport · Livraison</span><strong>0,02 s <span>DE LATENCE</span></strong></div>`;
    const svg = feature.querySelector('.route-map');
    svg.querySelectorAll('.packet').forEach(el => el.remove());
    const cube = (cls,top,front,side,edge) => `<g class="flow-container ${cls}"><path d="M-17-5-3-13 17-4 3 4Z" fill="${top}"/><path d="M-17-5 3 4V20L-17 11Z" fill="${front}"/><path d="M3 4 17-4V12L3 20Z" fill="${side}"/><path d="M-17-5-3-13 17-4V12L3 20-17 11Z M-17-5 3 4 17-4 M3 4V20 M-11-2V13 M-5 1V16 M10 0V16" fill="none" stroke="${edge}" stroke-width=".9" stroke-linejoin="round"/></g>`;
    svg.insertAdjacentHTML('beforeend',cube('container-a','#45E5DD','#0D676C','#11AD93','#B1FFF1')+cube('container-b','#67EEC3','#116654','#0DBB8D','#B1FFF1')+cube('container-c','#70D9FF','#195C91','#258FCD','#C9F3FF'));
    scene.appendChild(feature);
  }
  tl.addLabel('assembly',4);
  tl.fromTo('.assembly-inner',{opacity:0},{opacity:1,duration:.1},4);
  tl.fromTo('.assembly-copy .eyebrow',{y:22,opacity:0},{y:0,opacity:1,duration:.3,ease:'power3.out'},4.19);
  tl.fromTo('.assembly-line.first',{yPercent:120,skewY:-5},{yPercent:0,skewY:0,duration:.42,ease:'power4.out'},4.28);
  tl.fromTo('.assembly-line.second',{yPercent:115,skewY:-4},{yPercent:0,skewY:0,duration:.43,ease:'power4.out'},4.47);
  // One product surface emerges through the central portal, with real depth.
  tl.fromTo('.assembly-camera',{x:0,y:35,z:-1100,scale:.24,rotationX:24,rotationY:57,rotationZ:12,opacity:0},{x:0,y:-8,z:0,scale:.78,rotationX:10,rotationY:-10,rotationZ:-3,opacity:1,duration:.93,ease:'expo.out'},4.03);
  tl.fromTo('#assembly-dashboard .omni-sidebar',{x:-45,opacity:0},{x:0,opacity:1,duration:.4,ease:'power4.out'},4.5);
  tl.fromTo('#assembly-dashboard .app-topbar',{y:-28,opacity:0},{y:0,opacity:1,duration:.4,ease:'power4.out'},4.56);
  tl.fromTo('#assembly-dashboard .metric-card',{y:75,z:210,rotationX:38,opacity:0},{y:0,z:0,rotationX:0,opacity:1,stagger:.065,duration:.47,ease:'back.out(1.4)'},4.7);
  tl.fromTo('#assembly-dashboard .panel',{y:70,scale:.94,opacity:0},{y:0,scale:1,opacity:1,stagger:.09,duration:.48,ease:'power4.out'},5);
  tl.fromTo('#assembly-dashboard .shipment-row',{x:28,opacity:0},{x:0,opacity:1,stagger:.05,duration:.35,ease:'power3.out'},5.35);
  tl.fromTo('#assembly-dashboard .chart-line',{strokeDasharray:1000,strokeDashoffset:1000},{strokeDashoffset:0,duration:.54,ease:'power3.out'},5.26);
  tl.fromTo('#assembly-dashboard .route-line',{strokeDasharray:500,strokeDashoffset:500,opacity:0},{strokeDashoffset:0,opacity:1,stagger:.045,duration:.5,ease:'power3.out'},5.33);
  tl.fromTo('#assembly-dashboard .route-node',{scale:0,opacity:0,transformOrigin:'50% 50%'},{scale:1,opacity:1,stagger:.045,duration:.3,ease:'back.out(2)'},5.57);
  tl.fromTo('#assembly-dashboard .packet',{opacity:0},{opacity:1,duration:.16,stagger:.04},5.71);
  tl.fromTo('.sync-chip',{x:-90,y:30,rotationY:25,scale:.7,opacity:0},{x:0,y:0,rotationY:0,scale:1,opacity:1,duration:.42,ease:'back.out(1.4)'},5.43);
  tl.fromTo('.network-chip',{x:90,y:20,scale:.75,opacity:0},{x:0,y:0,scale:1,opacity:1,duration:.42,ease:'back.out(1.4)'},5.66);
  tl.fromTo('.assembly-shine',{x:-1050},{x:650,duration:.95,ease:'power2.inOut'},5.05);
  tl.to('.assembly-camera',{rotationX:5,rotationY:-3,rotationZ:-1,y:-20,duration:1,ease:'sine.inOut'},5.14);
  // Detach the network region into a macro shot. The headline stays readable.
  tl.to(['.sync-chip','.network-chip'],{opacity:0,scale:.9,duration:.18,ease:'power2.in'},6.12);
  tl.to('.assembly-camera',{scale:.62,x:60,y:-70,rotationX:19,rotationY:-20,rotationZ:-3,opacity:0,duration:.48,ease:'power3.inOut'},6.13);
  tl.fromTo('.network-focus',{x:-165,y:58,z:-180,scale:.54,rotationX:23,rotationY:-17,rotationZ:-4,opacity:0},{x:0,y:0,z:0,scale:1,rotationX:4,rotationY:-4,rotationZ:-.6,opacity:1,duration:.59,ease:'expo.out'},6.19);
  tl.fromTo('.focus-heading',{y:13,opacity:0},{y:0,opacity:1,duration:.32,ease:'power3.out'},6.38);
  tl.fromTo('.focus-insight',{x:55,opacity:0},{x:0,opacity:1,duration:.48,ease:'power4.out'},6.48);
  tl.fromTo('.network-focus .route-line',{strokeDasharray:500,strokeDashoffset:500,opacity:0},{strokeDashoffset:0,opacity:1,stagger:.055,duration:.47,ease:'power2.out'},6.38);
  tl.fromTo('.network-focus .route-node',{scale:0,opacity:0,transformOrigin:'50% 50%'},{scale:1,opacity:1,stagger:.04,duration:.34,ease:'back.out(2)'},6.62);
  tl.fromTo('.focus-bottom',{y:12,opacity:0},{y:0,opacity:1,duration:.35,ease:'power3.out'},6.56);
  tl.fromTo('.focus-route-card',{y:20,opacity:0},{y:0,opacity:1,duration:.39,ease:'back.out(1.15)'},6.79);
  // Eight deterministic samples follow each quadratic SVG shipping route.
  const flyContainer=(selector,a,control,b,start,duration)=>{
    tl.fromTo(selector,{x:a[0],y:a[1]-9,scale:.65,opacity:0,transformOrigin:'0px 0px'},{x:a[0],y:a[1]-9,scale:1,opacity:1,duration:.15,ease:'back.out(1.4)'},start);
    for(let step=1;step<=8;step++){
      const u=step/8,v=1-u,x=v*v*a[0]+2*v*u*control[0]+u*u*b[0],y=v*v*a[1]+2*v*u*control[1]+u*u*b[1]-9;
      tl.to(selector,{x,y,duration:duration/8,ease:'none'},start+.15+(step-1)*duration/8);
    }
  };
  flyContainer('.container-a',[113,83],[220,7],[347,68],6.72,1.2);
  flyContainer('.container-b',[347,68],[447,13],[569,95],6.85,1.17);
  flyContainer('.container-c',[382,141],[475,98],[569,95],6.96,1.14);
  tl.to('.network-focus .route-node',{scale:1.4,duration:.25,repeat:1,yoyo:true,stagger:.07,ease:'sine.inOut'},7.31);
  tl.to('.network-focus',{rotationY:3,rotationX:1,rotationZ:0,x:12,y:-7,duration:1.75,ease:'sine.inOut'},6.81);
  tl.fromTo('.focus-route-success',{opacity:0,y:8},{opacity:1,y:0,duration:.28,ease:'power3.out'},7.78);
  // Match the product into the titanium screen of the demonstration at t=9.
  tl.to('.network-focus',{x:-220,y:-65,scale:.43,rotationX:14,rotationY:-8,opacity:0,duration:.48,ease:'power3.inOut'},8.43);
  tl.to('.assembly-camera',{x:0,y:-121,z:0,scale:.82,rotationX:5,rotationY:-8,rotationZ:-2,opacity:1,duration:.48,ease:'power3.inOut'},8.43);
  tl.to('.assembly-copy',{y:-28,opacity:0,duration:.22,ease:'power3.in'},8.72);
  tl.to('.assembly-inner',{opacity:0,duration:.14},9.01);
};
