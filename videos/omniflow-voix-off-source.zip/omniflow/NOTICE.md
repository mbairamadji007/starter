# Ressources tierces

- **GSAP 3.14.2** — `assets/vendor/gsap.min.js`. Copyright 2025 GreenSock,
  tous droits réservés. Auteur indiqué par le fournisseur : Jack Doyle.
  L’en-tête original est conservé ; conditions de la licence standard :
  https://gsap.com/standard-license.
- **Inter** — `assets/fonts/InterVariable.woff2`. Copyright 2016 The Inter
  Project Authors : https://github.com/rsms/inter. SIL Open Font License 1.1,
  texte complet conservé dans `assets/fonts/OFL.txt`.
- **HyperFrames / motion-blur** — `assets/vendor/motion-blur.js` provient du
  composant officiel `motion-blur` du projet https://github.com/heygen-com/hyperframes.
  Le paquet HyperFrames 0.8.145 déclare la licence Apache-2.0 ; une copie du
  texte standard est fournie dans `licenses/APACHE-2.0.txt`. La notice conserve
  cette provenance même si le snippet ne comporte pas d’en-tête de licence.
- **Voix française Siwis medium / Piper VITS** — synthèse locale avec
  sherpa-onnx 1.13.8. Modèle distribué par le projet sherpa-onnx :
  https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-fr_FR-siwis-medium.tar.bz2.
  La fiche d’origine est conservée dans `assets/audio/SIWIS-MODEL-CARD.txt`.
  Le jeu de données **SIWIS French Speech Synthesis Database**, University of
  Edinburgh, est attribué sous **CC BY 4.0** :
  https://datashare.is.ed.ac.uk/handle/10283/2353 ;
  https://creativecommons.org/licenses/by/4.0/.
  La voix est générée depuis une source à 22,05 kHz, puis rééchantillonnée et
  mixée dans la bande sonore à 48 kHz. Le moteur sherpa-onnx est sous licence
  Apache-2.0 : https://github.com/k2-fsa/sherpa-onnx.

Les dépendances npm de HyperFrames restent couvertes par leurs licences
respectives, distribuées avec les paquets installés par `npm ci`.
