---
workflow: product-launch-video
flow: autonomous
duration: 15
fps: 60
width: 1920
height: 1080
language: fr
voice: fr_FR-siwis-medium
music: original-local-synthesis
version: 2
---

# OmniFlow — motion design et voix off française

Refonte demandée par l’utilisateur après transmission de quatre références
motion design : Flowz, ProductHype, Taskip et Wegic. Le film reprend leur
continuité spatiale, leurs mouvements de caméra, leurs gestes de démonstration
et leurs révélations typographiques, en conservant l’identité OmniFlow.

SaaS B2B de gestion logistique en temps réel : fond ardoise `#090D16`, cyan
`#00F2FE`, bleu `#4FACFE`, succès émeraude `#00F5A0`, Inter Display et interface
originale de démonstration. Les scènes alternent composition large et détail
fonctionnel : alertes, aspiration dans un portail, dashboard, réseau en gros
plan, travelling autour de l’écran, clic et résultat, URL dans une capsule de
verre puis CTA.

Voix off française féminine issue d’une synthèse neuronale locale Siwis.
Quatre phrases suivent les quatre bénéfices : question logistique, unification
du dashboard, gain d’efficacité et invitation à l’essai gratuit. La source
vocale à 22,05 kHz est rééchantillonnée dans le master stéréo à 48 kHz.
Musique et effets originaux à 120 BPM, avec espace laissé à la voix.

Rendu : 15 secondes, 1920 × 1080, 60 FPS, 900 images, H.264 avec audio AAC
stéréo. Toutes les ressources de lecture sont locales ; les modèles vocaux
ne sont nécessaires que pour régénérer la narration.
