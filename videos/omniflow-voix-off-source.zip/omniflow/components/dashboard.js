/* OmniFlow product UI: static, deterministic, locally rendered vectors. */
(function () {
  "use strict";

  const icon = (name, cls = "") => {
    const paths = {
      grid: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
      truck: '<path d="M3 6h11v11H3zM14 10h4l3 4v3h-7"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
      box: '<path d="m12 3 9 5-9 5-9-5 9-5Zm-9 5v10l9 5 9-5V8M12 13v10M7 5.8l9 5"/>',
      globe: '<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18M5 6.5h14M5 17.5h14"/>',
      chart: '<path d="M4 3v17h17M8 14l4-4 4 2 5-7"/>',
      settings: '<path d="m10 3-1 3-3 1-2-1-2 4 2 2v3l-2 2 2 4 3-1 2 1 1 3h4l1-3 3-1 2 1 2-4-2-2v-3l2-2-2-4-3 1-2-1-1-3h-4Z"/><circle cx="12" cy="13" r="3"/>',
      arrow: '<path d="M5 12h14m-5-5 5 5-5 5"/>',
      up: '<path d="m5 15 5-5 4 4 5-9M13 5h6v6"/>',
      check: '<path d="m5 12 4 4L19 6"/>',
      search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m15.5 15.5 5 5"/>',
      bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9ZM9 21h6"/>',
      bolt: '<path d="m13 2-9 12h7l-1 8 10-13h-7l0-7Z"/>',
      chevron: '<path d="m8 5 7 7-7 7"/>',
      ship: '<path d="M7 11V4h10v7M12 3v8m-9 1 9-3 9 3-3 7H6l-3-7ZM3 21c3-2 3 2 6 0s3 2 6 0 3 2 6 0"/>'
    };
    return `<svg class="omni-icon ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.grid}</svg>`;
  };

  const brand = '<svg class="omni-brand-symbol" viewBox="0 0 112 112" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M56 10L98 34V78L56 102L14 78V34Z"/><path d="M16 35L56 58L96 35M56 58V100M36 23L77 47V88"/></svg>';

  function map(prefix) {
    return `<svg class="route-map" viewBox="0 0 744 242" aria-label="Carte mondiale des flux logistiques" role="img">
      <defs>
        <linearGradient id="${prefix}-map-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#28404b"/><stop offset="1" stop-color="#172631"/></linearGradient>
        <linearGradient id="${prefix}-route" x1="0" x2="1"><stop stop-color="#00f2fe"/><stop offset="1" stop-color="#00f5a0"/></linearGradient>
      </defs>
      <g class="map-grid" stroke="#365266" stroke-width=".7" opacity=".25"><path d="M0 41H744M0 82H744M0 123H744M0 164H744M0 205H744M62 0V242M124 0V242M186 0V242M248 0V242M310 0V242M372 0V242M434 0V242M496 0V242M558 0V242M620 0V242M682 0V242"/></g>
      <g class="world-land" fill="url(#${prefix}-map-fill)" stroke="#406073" stroke-width=".65">
        <path d="M45 53 62 41 78 40 89 30 115 32 136 44 151 39 167 43 180 55 194 61 191 71 177 76 169 91 153 92 145 108 130 113 119 127 108 125 93 111 85 96 65 94 55 77 43 70Z"/>
        <path d="m103 123 14 5 8 15 16 4 9 13 9 3 12 15-4 21-11 15-6 20-12 4-5-17-11-11-4-21-7-10-2-23-7-14Z"/>
        <path d="m194 30 19-16 28 5 9 13-7 18-14 13-20-3-8-16Z"/>
        <path d="m323 58 10-11 23 1 14 10 13 2 11 10-3 13-18 1-4 11-13 3-7-12-22-6-9-11Z"/>
        <path d="m345 92 23-7 22 13 19 3 8 16-5 20-14 15-4 24-16 25-13 2-12-21-3-22-11-15-6-29Z"/>
        <path d="m377 49 14-14 29 5 21-8 39 5 26-11 22 8 41-1 14 13 32 2 18 17 12 5-7 16-22 4-13-10-17 1-9 15-22 0-12 18-18-1-13 12-7 20-11 3-11-16-13-4-6-16-26-1-7-13-19-1-7-10-13 1-9-12Z"/>
        <path d="m481 118 14 6 5 18 10 4 8 19 17 5 7 17-11 5-18-14-10-17-13-12-7-17Z"/>
        <path d="m541 127 9 2 11 13-2 10-11-10ZM566 155l15 1 10 9 13-1 8 9-9 8-22-8-10-4ZM615 161l22 2 23 18 4 22-12 11-23 1-13-8-19-4-3-16 8-17Z"/>
        <path d="m667 117 8-13 6 3-3 18-6 6ZM396 185l6-8 4 13-4 18-7 3ZM696 204l6 2-3 15-8 6-3-4Z"/>
      </g>
      <g fill="none" stroke-linecap="round">
        <path class="route-line route-cyan" d="M113 83Q220 7 347 68" stroke="url(#${prefix}-route)" stroke-width="2.8"/>
        <path class="route-line route-green" d="M347 68Q447 13 569 95" stroke="#00f5a0" stroke-width="2.8"/>
        <path class="route-line route-cyan" d="M113 83Q198 153 382 141" stroke="#00f2fe" stroke-width="2.4"/>
        <path class="route-line route-green" d="M382 141Q475 98 569 95" stroke="#00f5a0" stroke-width="2.4"/>
        <path class="route-line route-cyan" d="M569 95Q596 139 635 186" stroke="#4facfe" stroke-width="2.4"/>
      </g>
      <g class="route-rings" fill="none" stroke="#00f2fe" stroke-width="1" opacity=".25"><circle cx="113" cy="83" r="12"/><circle cx="347" cy="68" r="12"/><circle cx="382" cy="141" r="12"/><circle cx="569" cy="95" r="12"/><circle cx="635" cy="186" r="12"/></g>
      <g class="map-nodes"><circle class="route-node" cx="113" cy="83" r="4.8" fill="#00f2fe"/><circle class="route-node" cx="347" cy="68" r="4.8" fill="#00f5a0"/><circle class="route-node" cx="382" cy="141" r="4.8" fill="#00f2fe"/><circle class="route-node" cx="569" cy="95" r="4.8" fill="#00f5a0"/><circle class="route-node" cx="635" cy="186" r="4.8" fill="#4facfe"/></g>
      <g class="map-labels" fill="#c2d6e1" font-size="13" font-weight="550"><text x="88" y="105">New York</text><text x="318" y="91">Rotterdam</text><text x="355" y="163">Douala</text><text x="549" y="119">Singapour</text><text x="616" y="211">Sydney</text></g>
      <g class="packet" fill="#090d16" stroke="#00f2fe" stroke-width="1.4"><rect x="237" y="37" width="15" height="12" rx="2"/><path d="M242 38v10M246 38v10"/></g>
      <g class="packet" fill="#090d16" stroke="#00f5a0" stroke-width="1.4"><rect x="461" y="48" width="15" height="12" rx="2"/><path d="M466 49v10M470 49v10"/></g>
      <g class="packet" fill="#090d16" stroke="#00f5a0" stroke-width="1.4"><rect x="463" y="109" width="15" height="12" rx="2"/><path d="M468 110v10M472 110v10"/></g>
    </svg>`;
  }

  function lineChart(prefix) {
    return `<svg class="throughput-chart" viewBox="0 0 390 193" role="img" aria-label="Flux opérationnels en hausse">
      <defs><linearGradient id="${prefix}-chart-area" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#00f2fe" stop-opacity=".22"/><stop offset="1" stop-color="#00f2fe" stop-opacity="0"/></linearGradient></defs>
      <g class="chart-grid" stroke="#314355" stroke-width="1" opacity=".5"><path d="M38 19H375M38 60H375M38 101H375M38 142H375"/></g>
      <g class="chart-axis" fill="#9badbf" font-size="12"><text x="0" y="23">150%</text><text x="4" y="64">100%</text><text x="10" y="105">50%</text><text x="15" y="146">0%</text><text x="35" y="181">LUN</text><text x="113" y="181">MAR</text><text x="194" y="181">MER</text><text x="274" y="181">JEU</text><text x="349" y="181">VEN</text></g>
      <path class="chart-area" d="M39 139C63 137 67 129 88 128S115 115 129 117S151 96 170 98S203 76 218 76S246 64 263 67S290 45 307 47S340 23 372 19V151H39Z" fill="url(#${prefix}-chart-area)"/>
      <path class="chart-baseline" d="M39 135 88 137 129 122 170 129 218 119 263 122 307 114 372 103" fill="none" stroke="#495169" stroke-width="1.6" stroke-dasharray="4 5"/>
      <path class="chart-line" d="M39 139C63 137 67 129 88 128S115 115 129 117S151 96 170 98S203 76 218 76S246 64 263 67S290 45 307 47S340 23 372 19" fill="none" stroke="#00f2fe" stroke-width="3.5" stroke-linecap="round"/>
      <circle class="chart-point" cx="372" cy="19" r="7" fill="#090d16" stroke="#00f2fe" stroke-width="3"/>
    </svg>`;
  }

  function renderDashboard(options = {}) {
    const prefix = options.prefix === "demo" ? "demo" : "assembly";
    return `<div class="omni-dashboard" data-ui-instance="${prefix}">
      <aside class="omni-sidebar" aria-label="Navigation OmniFlow">
        <div class="sidebar-brand">${brand}</div>
        <div class="nav-item active">${icon("grid")}</div><div class="nav-item">${icon("truck")}</div><div class="nav-item">${icon("box")}</div><div class="nav-item">${icon("globe")}</div><div class="nav-item">${icon("chart")}</div>
        <div class="sidebar-spacer"></div><div class="nav-item">${icon("settings")}</div><div class="user-avatar">AM</div>
      </aside>
      <div class="omni-app">
        <header class="app-topbar"><div class="app-wordmark">OmniFlow<span class="workspace-divider"></span><span class="workspace-name">Workspace Europe</span><span class="workspace-chevron">⌄</span></div><div class="topbar-actions"><span class="topbar-search">${icon("search")}<span>Rechercher</span><kbd>⌘ K</kbd></span><span class="topbar-bell">${icon("bell")}<i></i></span><span class="team-badge">ÉQUIPE PRO</span></div></header>
        <main class="dashboard-main">
          <div class="dashboard-toolbar"><div><div class="dashboard-eyebrow">INTELLIGENCE LOGISTIQUE</div><h2>Vision d’ensemble <span class="live-chip"><i></i> LIVE</span></h2></div><div class="dashboard-tools"><span class="period-pill">7 derniers jours <span>⌄</span></span><div class="optimize-button">${icon("bolt")}<span>Optimiser les flux</span>${icon("arrow")}</div></div></div>
          <div class="metrics-grid">
            <div class="metric-card"><div class="metric-label">Expéditions actives${icon("truck")}</div><div class="metric-number-row"><span class="kpi-value" data-final-value="18432">18 432</span><span class="metric-delta">↗ 24,8%</span></div><div class="metric-caption"><span class="tiny-dot cyan"></span>À travers 42 pays</div><svg class="metric-sparkline" viewBox="0 0 95 23"><path d="m0 21 12-3 11 1 13-10 9 4 15-10 11 1 14-4"/></svg></div>
            <div class="metric-card"><div class="metric-label">Livraisons à temps${icon("check")}</div><div class="metric-number-row"><span class="kpi-value" data-final-value="98.6">98,6<span class="kpi-unit">%</span></span><span class="metric-delta">↗ 8,2%</span></div><div class="metric-caption"><span class="tiny-dot green"></span>SLA au-dessus de l’objectif</div><div class="sla-bar"><i></i></div></div>
            <div class="metric-card"><div class="metric-label">Coûts logistiques${icon("box")}</div><div class="metric-number-row"><span class="kpi-value" data-final-value="-32">−32<span class="kpi-unit">%</span></span><span class="metric-delta">↓ 12,4%</span></div><div class="metric-caption"><span class="tiny-dot blue"></span>Économies ce trimestre</div><svg class="metric-sparkline blue" viewBox="0 0 95 23"><path d="m0 2 14 2 12 4 11-3 11 9 13-3 10 7 13 4"/></svg></div>
            <div class="metric-card efficiency-card"><div class="metric-label">Efficacité opérationnelle${icon("bolt")}</div><div class="metric-number-row"><span class="kpi-value efficiency-value" data-final-value="140">+0<span class="kpi-unit">%</span></span><span class="efficiency-ready">AI</span></div><div class="metric-caption"><span class="tiny-dot green"></span>Propulsée par OmniFlow AI</div><div class="efficiency-accent"></div></div>
          </div>
          <div class="dashboard-panels">
            <section class="panel routes-panel"><div class="panel-heading"><h3>Votre réseau, en temps réel</h3><span class="network-status"><i></i> Tous les flux synchronisés</span></div>${map(prefix)}<div class="map-footer"><span><i class="legend-dot cyan"></i> Flux actifs</span><span><i class="legend-dot green"></i> Livraison optimisée</span><span class="map-live">Dernière synchro : <strong>0,02 s</strong></span></div></section>
            <section class="panel performance-panel"><div class="panel-heading"><h3>Performance des flux</h3><span class="panel-menu">···</span></div><div class="chart-summary"><strong>+140<span>%</span></strong><span>vs. semaine précédente</span><span class="chart-trend">${icon("up")}</span></div>${lineChart(prefix)}</section>
          </div>
          <section class="panel shipments-panel"><div class="panel-heading"><h3>Expéditions prioritaires <span class="shipment-count">12</span></h3><span class="all-shipments">Voir toutes les expéditions ${icon("arrow")}</span></div>
            <div class="shipment-table-head"><span>EXPÉDITION</span><span>TRAJET</span><span>PROGRESSION</span><span>STATUT</span><span>ARRIVÉE</span></div>
            <div class="shipment-row"><span class="shipment-id">${icon("ship")} OF–2048<span class="shipment-mode">MARITIME</span></span><span class="shipment-route">Rotterdam ${icon("arrow")} Singapour</span><span class="shipment-progress"><i class="milestone complete"></i><b></b><i class="milestone complete"></i><b></b><i class="milestone current"></i><b class="pending"></b><i class="milestone pending"></i></span><span class="status-badge"><i></i> En transit</span><span class="shipment-eta">Aujourd’hui, 14:30 ${icon("chevron")}</span></div>
            <div class="shipment-row"><span class="shipment-id">${icon("truck")} OF–2051<span class="shipment-mode">ROUTIER</span></span><span class="shipment-route">Lyon ${icon("arrow")} Hambourg</span><span class="shipment-progress"><i class="milestone complete"></i><b></b><i class="milestone complete"></i><b></b><i class="milestone complete"></i><b></b><i class="milestone complete"></i></span><span class="status-badge delivered">${icon("check")} Livrée</span><span class="shipment-eta">Aujourd’hui, 09:15 ${icon("chevron")}</span></div>
          </section>
        </main>
      </div>
      <div class="dashboard-rim"></div>
    </div>`;
  }

  window.OmniUI = { renderDashboard, icon, brand };
})();
