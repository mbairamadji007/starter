/* Seek-safe card choreography. All coordinates and particle paths are fixed.
 * Every sub-composition owns one paused timeline; the framework nests it. */
window.CR7Builders=(()=>{
  const select=(name,selector)=>`.${name}-card ${selector}`;
  const barcode='<svg viewBox="0 0 300 48" fill="currentColor" aria-hidden="true">'+Array.from({length:48},(_,i)=>`<rect x="${i*6}" width="${[2,4,1,3,2,1,4][i%7]}" height="${i%11===0?48:41}"/>`).join('')+'</svg>';
  function footer(name){document.querySelectorAll(`.${name}-card .card-barcode`).forEach(el=>el.innerHTML=barcode);}
  function legend(tl){
    footer('legend');const s=q=>select('legend',q);
    tl.fromTo(s('.card-pose'),{y:-900,z:180,scale:1.07,rotationX:18,rotationZ:-5,opacity:0},{y:0,z:0,scale:1,rotationX:0,rotationZ:0,opacity:1,duration:.64,ease:'expo.out'},0);
    tl.fromTo(s('.portrait-legend'),{y:88,scale:.97,opacity:0},{y:0,scale:1,opacity:1,duration:.64,ease:'power4.out'},.1);
    tl.fromTo(s('.legend-name'),{y:20,opacity:0},{y:0,opacity:1,duration:.3},.2);
    tl.fromTo(s('.small-kicker'),{x:-24,opacity:0},{x:0,opacity:1,duration:.3},.39);
    tl.fromTo(s('.legend-title span'),{y:88,rotationX:-19,opacity:0},{y:0,rotationX:0,opacity:1,duration:.43,stagger:.11,ease:'power4.out'},.45);
    tl.fromTo(s('.legend-caption'),{y:14,opacity:0},{y:0,opacity:1,duration:.3},.91);
    tl.to(s('.card-pose'),{scale:1.017,duration:2.2,ease:'sine.inOut'},.9);
    tl.to(s('.card-pose'),{x:-80,rotationY:-87,scale:.94,duration:.35,ease:'power3.in'},3.28);
    tl.to(s('.card-pose'),{opacity:0,duration:.12,ease:'power2.in'},3.3);
  }
  function trophies(tl){
    footer('trophies');const s=q=>select('trophies',q);
    document.querySelector(s('.trophy-ball')).innerHTML=window.CR7Trophies.ball;
    document.querySelector(s('.trophy-ucl')).innerHTML=window.CR7Trophies.ucl;
    tl.fromTo(s('.card-pose'),{x:40,rotationY:87,scale:.94,opacity:0},{x:0,rotationY:0,scale:1,opacity:1,duration:.53,ease:'power4.out'},.04);
    tl.fromTo(s('.trophy-heading span'),{y:30,opacity:0},{y:0,opacity:1,duration:.38,stagger:.08},.28);
    tl.fromTo(s('.trophy-ball'),{y:125,z:-200,scale:.65,rotationY:-24,rotationZ:-9,opacity:0},{y:0,z:0,scale:1,rotationY:0,rotationZ:0,opacity:1,duration:.62,ease:'back.out(1.5)'},.45);
    tl.fromTo(s('.trophy-ucl'),{y:145,z:-180,scale:.68,rotationY:28,rotationZ:8,opacity:0},{y:0,z:0,scale:1,rotationY:0,rotationZ:0,opacity:1,duration:.6,ease:'back.out(1.35)'},.68);
    tl.fromTo(s('.ball-stat'),{x:-55,opacity:0},{x:0,opacity:1,duration:.39,ease:'power4.out'},.83);
    tl.fromTo(s('.ucl-stat'),{x:55,opacity:0},{x:0,opacity:1,duration:.39,ease:'power4.out'},1.19);
    tl.fromTo(s('.trophy-caption'),{y:16,opacity:0},{y:0,opacity:1,duration:.27},1.61);
    tl.to(s('.trophy-ball'),{rotationY:7,duration:1.1,ease:'sine.inOut'},1.28);
    tl.to(s('.trophy-ucl'),{rotationY:-6,duration:1.1,ease:'sine.inOut'},1.45);
    tl.fromTo(s('.trophy-glint'),{opacity:0,scale:.1},{opacity:1,scale:1,duration:.13,stagger:.22,ease:'power2.out'},1.1);
    tl.to(s('.trophy-glint'),{opacity:0,scale:.45,duration:.23,stagger:.22},1.24);
    tl.to(s('.card-pose'),{y:-65,rotationX:-84,duration:.35,ease:'power3.in'},3.97);
    tl.to(s('.card-pose'),{opacity:0,duration:.12,ease:'power2.in'},4.0);
  }
  function record(tl){
    footer('record');const s=q=>select('record',q);
    for(const strip of document.querySelectorAll(s('.digit-strip'))){
      for(let i=0;i<30;i++){const span=document.createElement('span');span.textContent=String(i%10);
        // Neighbouring digits live outside the intentional 320px roller mask.
        for(const attr of ['data-layout-allow-overlap','data-layout-allow-occlusion','data-layout-allow-overflow'])span.setAttribute(attr,'');
        strip.appendChild(span);
      }
    }
    const field=document.querySelector(s('.spark-field'));
    for(let i=0;i<24;i++){const dot=document.createElement('i');dot.className='spark';dot.style.left=`${150+(i*97)%650}px`;dot.style.top=`${590+(i*73)%460}px`;field.appendChild(dot);
      tl.fromTo(dot,{x:0,y:0,scale:.2,opacity:0},{x:(i%2?1:-1)*(70+(i*31)%100),y:-140-(i*29)%190,scale:.7+(i%3)*.25,opacity:.85,duration:.2,ease:'power2.out'},1.54+(i%7)*.055);
      tl.to(dot,{y:-260-(i*19)%150,opacity:0,duration:.64,ease:'power2.out'},1.74+(i%7)*.055);
    }
    tl.fromTo(s('.card-pose'),{y:140,scale:.985,opacity:0},{y:0,scale:1,opacity:1,duration:.36,ease:'expo.out'},.04);
    tl.fromTo(s('.record-title'),{x:-30,opacity:0},{x:0,opacity:1,duration:.31},.18);
    tl.fromTo(s('.euro-year'),{opacity:0},{opacity:1,duration:.25},.33);
    tl.fromTo(s('.record-emblem'),{scale:.6,rotationY:-50,opacity:0},{scale:1,rotationY:0,opacity:1,duration:.47,ease:'back.out(1.4)'},.3);
    tl.fromTo(s('.record-counter'),{y:36,opacity:0},{y:0,opacity:1,duration:.24},.49);
    tl.fromTo(s('.digit-hundreds'),{y:0},{y:-9280,duration:1.08,ease:'power4.out'},.75);
    tl.fromTo(s('.digit-tens'),{y:0},{y:-6400,duration:1.17,ease:'power4.out'},.75);
    tl.fromTo(s('.digit-units'),{y:0},{y:-6400,duration:1.3,ease:'power4.out'},.75);
    tl.fromTo(s('.record-plus'),{scale:.65,opacity:0},{scale:1,opacity:1,duration:.3,ease:'back.out(2)'},1.88);
    tl.fromTo(s('.record-tore'),{y:22,opacity:0},{y:0,opacity:1,duration:.27},.7);
    tl.fromTo(s('.record-line'),{scaleX:0},{scaleX:1,duration:.42,ease:'power3.out'},1.29);
    tl.fromTo(s('.record-label'),{y:24,opacity:0},{y:0,opacity:1,duration:.3},1.4);
    tl.fromTo(s('.record-support'),{y:16,opacity:0},{y:0,opacity:1,duration:.3},1.55);
    tl.fromTo(s('.record-caption'),{opacity:0},{opacity:1,duration:.24},2.1);
    tl.to(s('.card-pose'),{scale:.96,y:-35,duration:.3,ease:'power3.in'},4.03);
    tl.to(s('.card-pose'),{opacity:0,duration:.11,ease:'power2.in'},4.06);
  }
  function final(tl){
    footer('final');const s=q=>select('final',q);
    tl.fromTo(s('.card-pose'),{y:40,scale:.977,opacity:0},{y:0,scale:1,opacity:1,duration:.37,ease:'power4.out'},.07);
    tl.fromTo(s('.portrait-final'),{y:40,scale:.99,opacity:0},{y:0,scale:1,opacity:1,duration:.39,ease:'power3.out'},.25);
    tl.fromTo(s('.final-subtitle'),{opacity:0},{opacity:1,duration:.25},.36);
    tl.fromTo(s('.discipline span'),{y:28,opacity:0},{y:0,opacity:1,duration:.32,stagger:.1,ease:'power4.out'},.69);
    tl.fromTo(s('.ultimate span'),{y:38,rotationX:-12,opacity:0},{y:0,rotationX:0,opacity:1,duration:.43,stagger:.1,ease:'power4.out'},1.17);
    // Camera and hero remain locked after their entrance; final message holds.
  }
  return {legend,trophies,record,final};
})();
