# CR7 — hommage cinématique en allemand

Film vertical de **15 secondes**, en **1080 × 1920 à 60 images/s**, avec voix
off masculine allemande. Quatre cartes relient le portrait de Cristiano Ronaldo,
les trophées, les records et la discipline. Les titres, statistiques et petits
labels visibles sont en allemand. Le portrait généré est utilisé dans deux
cadrages ; la musique et les effets sont originaux.

## Installation et rendu

Prérequis : **Node.js 22 ou supérieur**, npm, **FFmpeg** et FFprobe dans le
`PATH`, ainsi qu’un navigateur Chromium compatible. HyperFrames est fixé à
**0.8.145** et le verrou npm est fourni.

Depuis le dossier source extrait :

```bash
npm ci
npm run check
npm run preview
npm run render
```

Le fichier produit est **`renders/cr7-tribute-de.mp4`**, en H.264 avec son AAC.
Le rendu est réglé à **15 secondes / 900 images**, format vertical **9:16**,
60 images/s, qualité `delivery`, CRF 16 et deux workers. Le canevas est déclaré
sur la racine de `index.html` :

```html
data-width="1080" data-height="1920" data-duration="15" data-fps="60"
```

`npm run preview` lance une session Studio persistante en arrière-plan : ouvrir
l’URL affichée. `npm run preview:status` vérifie la session, et
`npm run preview:stop` l’arrête. `npm run dev` donne l’aperçu au premier plan.
`npm run snapshot` capture quatre images à 1,5 / 5,5 / 9,5 / 13,5 secondes.

La cadence du MP4 est de 60 images/s. Le temps de calcul et la fluidité de
l’aperçu dépendent du navigateur et du matériel. Pour une machine avec peu de
mémoire :

```bash
npm run render -- --workers 1 --low-memory-mode
```

Pour utiliser un Chromium déjà installé, définir `HYPERFRAMES_BROWSER_PATH`
avec son chemin absolu. Les polices, GSAP, images, textures et WAV sont locaux.
L’installation initiale du CLI et éventuellement du navigateur demande une
connexion. Les modèles vocaux ne participent pas au rendu.

Vérifier le format et la durée du MP4 :

```bash
ffprobe -v error -show_entries stream=codec_name,width,height,r_frame_rate,nb_frames -show_entries format=duration -of json renders/cr7-tribute-de.mp4
```

## Découpage et personnalisation

| Fenêtre principale | Carte | Mouvement et contenu |
| --- | --- | --- |
| 0–3,5 s | CR7 · DIE LEGENDE | Fond blanc cassé, portrait, révélation de « ABSOLUTE LEGENDE » |
| 3,5–7,5 s | Palmarès | Bascule vers le vert forêt et l’or, deux trophées, deux statistiques 5× |
| 7,5–11,5 s | Records | Fond sombre, badge « EUROPAMEISTER », compteur 900+ |
| 11,5–15 s | Héritage | Portrait SIUU, « DISZIPLIN & BESTÄNDIGKEIT », « DAS ULTIMATIVE VORBILD » |

| Fichier | Rôle |
| --- | --- |
| `index.html` | Racine de 15 s, quatre hosts, transitions globales et master audio |
| `compositions/legend.html` | Carte claire, portrait et révélation de la légende |
| `compositions/trophies.html` | Carte verte et or, trophées et statistiques 5× |
| `compositions/record.html` | Carte sombre, badge européen et compteur 900+ |
| `compositions/final.html` | Carte finale, portrait SIUU et message de discipline |
| `scenes/card-scenes.js` | Chorégraphies locales et animation des quatre cartes |
| `styles/cards.css` | Mise en page verticale, matières, lumière et typographie |
| `components/trophies.js` / `styles/trophies.css` | Trophées vectoriels et finitions |
| `assets/images/ronaldo-siuu.png` | Portrait généré RGBA, 1024 × 1536, détourage transparent |
| `assets/audio/` / `scripts/` | Master, stems, prises vocales et générateurs facultatifs |

Chaque sous-composition construit sa propre timeline GSAP en pause et
l’enregistre sur `window.__timelines`, avec une clé identique à son
`data-composition-id`. HyperFrames les imbrique selon les hosts déclarés dans
`index.html`. Les animations locales restent séparées des trois transitions
globales à 3,5 / 7,5 / 11,5 s. Le même portrait est recadré par CSS dans
l’ouverture et la finale ; les images à chaque temps sont reproductibles.

Les hosts se chevauchent aux transitions : **0–3,70 s**, **3,34–7,68 s**,
**7,32–11,72 s** et **11,36–15 s**. Les durées et gestes détaillés sont dans
`STORYBOARD.md`.

Pour modifier les titres, garder la narration et les gestes visuels alignés.
Après toute modification, exécuter `npm run check`, puis examiner les captures
avec `npm run snapshot`. `npm run check -- --snapshots` ajoute les images
annotées de l’audit. Les contrôles couvrent les ressources, le runtime, les
placements, la motion déclarée et le contraste.

## Narration allemande intégrale

Le texte fourni par l’utilisateur est conservé dans la voix off :

> Cristiano Ronaldo ist eine absolute Legende des Weltfußballs: 5-maliger Ballon-d’Or-Gewinner, 5 Champions-League-Titel, Europameister mit Portugal und der Rekordtorschütze der Geschichte des Profifußballs mit über 900 Toren. Ein Vorbild an Arbeitsmoral und Beständigkeit auf höchstem Niveau.

La voix allemande **Thorsten-high** est synthétisée localement avec
**sherpa-onnx 1.13.8 / Piper VITS**. La source à **22,05 kHz** est
rééchantillonnée pour le master stéréo à **48 kHz**. Le débit des prises est
ajusté pour conserver toutes les phrases dans les 15 secondes. Les fichiers
WAV sont fournis : aucun calcul vocal ni téléchargement de modèle n’est
nécessaire pendant la prévisualisation ou l’export.

La troisième prise réunit « Europameister mit Portugal » et le record de
buts. Son réglage TTS est **1,65**, avec un débit accéléré pour garder le
texte intégral dans cette carte de 4 secondes. Les phrases de palmarès et de
record restent ainsi alignées sur leurs images.

Le master intégré est **`assets/audio/cr7-master.wav`** : 15,000 s, stéréo
48 kHz / PCM 16 bits, **−16,01 LUFS**, **−3,17 dBTP**, LRA **1,6 LU**.
La musique originale à 120 BPM s’atténue sous la narration ; les impacts
accompagnent les changements de carte à 0 / 3,5 / 7,5 / 11,5 s.

Pour régénérer musique, effets et mix avec les prises fournies, Python 3,
NumPy et FFmpeg suffisent : `npm run audio:build`. Pour recréer la narration,
installer aussi `sherpa-onnx==1.13.8` et `soundfile`, télécharger le modèle
indiqué dans `NOTICE.md`, puis lancer :

```bash
npm run audio:voice -- --model-dir /chemin/vits-piper-de_DE-thorsten-high
npm run audio:build
```

Les repères, instructions de mixage et commandes de régénération sont dans
**`SOUND_DESIGN.md`**. Les attributions des portraits, de la voix et des
bibliothèques sont dans **`NOTICE.md`**.
