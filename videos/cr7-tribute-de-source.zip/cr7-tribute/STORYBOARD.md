# CR7 — quatre cartes, 15 secondes

Les repères éditoriaux sont **0 / 3,5 / 7,5 / 11,5 / 15 secondes**. Les
fenêtres réelles des hosts incluent les chevauchements nécessaires aux flips
et aux révélations. Le film reste de 15 s, soit 900 images à 60 images/s.

| Bloc | Sous-composition | Fenêtre réelle du host | Durée déclarée | Repère éditorial |
| --- | --- | --- | --- | --- |
| 01 — Legende | `compositions/legend.html` | 0,00–3,70 s | 3,70 s | 0–3,5 s |
| 02 — Trophées | `compositions/trophies.html` | 3,34–7,68 s | 4,34 s | 3,5–7,5 s |
| 03 — Records | `compositions/record.html` | 7,32–11,72 s | 4,40 s | 7,5–11,5 s |
| 04 — Héritage | `compositions/final.html` | 11,36–15,00 s | 3,64 s | 11,5–15 s |

## Bloc 01 — Die Legende

Carte blanc cassé qui descend avec un arrêt net. Le portrait de Ronaldo en
célébration entre, puis le nom et « ABSOLUTE LEGENDE » se révèlent par groupes.
Lumière dorée, cadre de collection et hiérarchie nette. La carte pivote en Y
pour passer au palmarès.

Voix de **0,250 à 3,398479 s** :
« Cristiano Ronaldo ist eine absolute Legende des Weltfußballs: »

Impact d’ouverture à **0 s** ; anticipation sonore à **3,25 s**.

## Bloc 02 — Palmarès

Carte forêt et or révélée par le flip. Le Ballon d’Or et la coupe européenne
s’assemblent en profondeur ; reflets courts et statistiques **5×** arrivent
successivement. Les trophées conservent une légère rotation puis la carte
bascule autour de l’axe X.

Voix de **3,580 à 6,775375 s** :
« 5-maliger Ballon-d’Or-Gewinner, 5 Champions-League-Titel, »

Impact de transition à **3,50 s** ; anticipation suivante à **7,25 s**.

## Bloc 03 — Records

Carte sombre avec badge **EUROPAMEISTER**, symbole européen et année. Le
compteur mécanique défile jusqu’à **900+** ; petites étincelles et ligne
lumineuse soulignent le résultat. « TORE » et les textes de record restent
lisibles après l’animation. La carte se réduit pour préparer la finale.

Voix de **7,630 à 11,347604 s** :
« Europameister mit Portugal und der Rekordtorschütze der Geschichte des Profifußballs mit über 900 Toren. »
Le réglage TTS de cette prise est 1,65 pour conserver le texte complet dans
la carte de records ; la voix adopte donc un débit accéléré sur ce bloc.

Impact de transition à **7,50 s** ; anticipation suivante à **11,25 s**.

## Bloc 04 — Das ultimative Vorbild

Carte sombre finale avec le même portrait transparent, recadré pour donner
plus de présence à la célébration SIUU. « DISZIPLIN & BESTÄNDIGKEIT » puis
« DAS ULTIMATIVE VORBILD » se révèlent. La caméra et le portrait se stabilisent
après leur arrivée ; le message reste à l’écran jusqu’à la dernière image.

Voix de **11,640 à 14,796375 s** :
« Ein Vorbild an Arbeitsmoral und Beständigkeit auf höchstem Niveau. »

Impact de transition à **11,50 s** ; résolution sonore à **14,80 s**, après
la dernière phrase complète.

## Contrat technique

La racine coordonne les flashes et lignes de transition. Chaque fichier de
carte enregistre une timeline locale en pause ; `scenes/card-scenes.js`
contient les quatre chorégraphies et HyperFrames assure leur imbrication.
Les temps vocaux ci-dessus sont absolus sur le film. `voice-cues.json`
conserve les durées mesurées et le texte d’origine ; `audio-mix.json`
conserve les accents sonores et mesures du master. Les titres et petits
labels visibles dans les cartes sont tous en allemand.
