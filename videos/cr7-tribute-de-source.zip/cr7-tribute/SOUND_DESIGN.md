# CR7 — narration allemande et bande originale

Le film utilise une voix masculine allemande **Thorsten-high**, synthétisée
localement avec **Piper VITS / sherpa-onnx 1.13.8**. Les prises sont calculées
avant le rendu ; HyperFrames lit les WAV synchronisés avec l’image.

## Texte et repères vocaux

Texte utilisateur conservé intégralement :

> Cristiano Ronaldo ist eine absolute Legende des Weltfußballs: 5-maliger Ballon-d’Or-Gewinner, 5 Champions-League-Titel, Europameister mit Portugal und der Rekordtorschütze der Geschichte des Profifußballs mit über 900 Toren. Ein Vorbild an Arbeitsmoral und Beständigkeit auf höchstem Niveau.

| Début | Fin mesurée | Prise et contenu |
| --- | --- | --- |
| 0,250 s | 3,398479 s | `voice-01-legende.wav` — Cristiano Ronaldo ist eine absolute Legende des Weltfußballs: |
| 3,580 s | 6,775375 s | `voice-02-titel.wav` — 5-maliger Ballon-d’Or-Gewinner, 5 Champions-League-Titel, |
| 7,630 s | 11,347604 s | `voice-03-tore.wav` — Europameister mit Portugal und der Rekordtorschütze der Geschichte des Profifußballs mit über 900 Toren. |
| 11,640 s | 14,796375 s | `voice-04-vorbild.wav` — Ein Vorbild an Arbeitsmoral und Beständigkeit auf höchstem Niveau. |

Le modèle reçoit les nombres sous leur forme orale : « Fünfmaliger », « fünf »
et « neunhundert ». Cette normalisation conserve le contenu d’origine. Les
vitesses TTS sont réglées par prise à **1,10 / 1,08 / 1,65 / 1,20**. Aucun mot
n’est supprimé ou coupé ; aucun étirement `atempo` n’est utilisé sur les prises.
La dernière phrase se termine avant 15 s.

La troisième prise utilise un débit accéléré pour regrouper le titre européen
et le record de buts sur la même carte. La référence à vitesse naturelle
durait **5,436 s** ; le réglage TTS 1,65 donne une prise complète de
**3,717604 s**. Ce choix conserve le texte intégral dans le format compact.

La source vocale est produite à **22 050 Hz**, puis convertie en WAV à
**48 000 Hz**. `voice-stem.wav` place les quatre prises dans une piste stéréo
alignée de 15 s, avec la voix au centre. `assets/audio/voice-cues.json`
conserve le texte exact, la forme prononcée, les repères mesurés, les vitesses,
la provenance et les empreintes des fichiers.

## Intégration dans le film

`assets/audio/cr7-master.wav` est la piste de 15 s utilisée par la composition,
en stéréo 48 kHz / PCM 16 bits. Elle combine voix, musique et effets originaux.
Mesure EBU R128 du master : **−16,01 LUFS intégrés**, **−3,17 dBTP** et
plage de dynamique **1,6 LU**. Les mesures et paramètres sont conservés dans
`assets/audio/audio-mix.json`.

Le master doit apparaître une seule fois :

```html
<audio
  id="cr7-sound"
  src="assets/audio/cr7-master.wav"
  data-start="0"
  data-duration="15"
  data-volume="1"
></audio>
```

L’ID doit être unique. HyperFrames possède la lecture, le placement temporel
et le mixage : ne pas ajouter d’`autoplay`, de timer ou d’appel `audio.play()`.
Le rendu à 60 images/s associe 0,25 s à l’image 15 ; les changements de carte
à 3,5 / 7,5 / 11,5 s correspondent aux images 210 / 450 / 690.

## Musique, impacts et place de la voix

La partition originale est synthétisée à **120 BPM**, avec une pulsation
grave et un arpège retenu en **ré mineur / si bémol**. Les effets sont eux
aussi créés par les scripts du projet.

| Temps | Image à 60 FPS | Geste sonore |
| --- | ---: | --- |
| 0 s | 0 | Impact cinématique d’ouverture |
| 3,25 s | 195 | Air de transition avant la carte des trophées |
| 3,50 s | 210 | Impact de bascule |
| 7,25 s | 435 | Air de transition avant les records |
| 7,50 s | 450 | Impact de bascule |
| 11,25 s | 675 | Air de transition avant la finale |
| 11,50 s | 690 | Impact de bascule |
| 14,80 s | 888 | Résolution finale après la dernière phrase |

Pendant les phrases, la musique baisse de **12,04 dB** et les effets de
**6,94 dB**, avec une anticipation de 90 ms et un retour de 150 ms. Des
réductions spectrales à 250 / 1 100 / 2 600 Hz dégagent la voix. Aucun fondu
global ne coupe la parole : le dernier mot se termine à 14,796375 s.

Tous les stems sont stéréo, durent 15 s et commencent à zéro :

| Fichier | Contenu |
| --- | --- |
| `music-stem.wav` | Partition originale avant ducking |
| `sfx-stem.wav` | Impacts, whooshes et résolution avant ducking |
| `instrumental.wav` | Musique et effets sans voix, avant ducking |
| `voice-stem.wav` | Quatre prises alignées avant le gain du master |
| `ducked-background.wav` | Fond musical et effets après traitement et gain final |
| `voice-mix-stem.wav` | Voix seule au niveau du master final |

La somme de **`ducked-background.wav` + `voice-mix-stem.wav`** retrouve le
master à l’arrondi PCM près. Pour les mixer dans HyperFrames, remplacer le
master par deux éléments `<audio>`, avec des IDs uniques, `data-start="0"`
et `data-duration="15"`. Les autres stems servent à reprendre le mixage.

## Modifier ou régénérer la bande sonore

Les WAV fournis suffisent pour rendre la vidéo, sans modèle vocal. Pour
reconstruire musique, effets et mix autour des prises existantes, installer
Python 3, NumPy et FFmpeg, puis lancer :

```bash
npm run audio:build
```

Le script `scripts/build_soundtrack.py` synthétise la bande originale et
recrée le master. Pour modifier une phrase, remplacer la prise correspondante
en conservant sa fenêtre temporelle, puis régénérer le mix. Garder la voix
centrée, dégager son niveau sous la musique et mesurer les crêtes après toute
modification. Ne pas superposer le master complet à ses stems.

Pour régénérer la voix, installer également `sherpa-onnx==1.13.8` et
`soundfile`. Télécharger puis extraire le modèle officiel :

<https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-de_DE-thorsten-high.tar.bz2>

Le modèle reste dans un dossier de travail externe au paquet source :

```bash
npm run audio:voice -- --model-dir /chemin/vits-piper-de_DE-thorsten-high
npm run audio:build
```

`generate_voice.py` utilise les textes et paramètres des quatre prises. Si
leurs durées changent, vérifier qu’elles tiennent dans les fenêtres de scène
et mettre à jour les repères avant de refaire le rendu.

## Provenance vocale

Modèle **de_DE-thorsten-high**, source Thorsten-Voice de **Thorsten Müller**,
jeu de données publié sous **CC0** :
<https://github.com/thorstenMueller/Thorsten-Voice>.
Licence : <https://creativecommons.org/publicdomain/zero/1.0/>.
La fiche du modèle est fournie dans `assets/audio/VOICE-MODEL-CARD.txt`.
Le moteur sherpa-onnx est distribué sous Apache-2.0.
