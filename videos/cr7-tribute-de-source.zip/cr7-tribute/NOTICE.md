# Provenance et ressources tierces

- **GSAP 3.14.2** — `assets/vendor/gsap.min.js`. Copyright 2025 GreenSock,
  tous droits réservés. Auteur indiqué par le fournisseur : Jack Doyle.
  L’en-tête original est conservé ; licence standard :
  https://gsap.com/standard-license.
- **Inter** — `assets/fonts/InterVariable.woff2`. Copyright 2016 The Inter
  Project Authors : https://github.com/rsms/inter. SIL Open Font License 1.1,
  texte complet conservé dans `assets/fonts/OFL.txt`.
- **Voix allemande Thorsten-high / Piper VITS** — synthèse locale avec
  sherpa-onnx 1.13.8. Modèle officiel :
  https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-de_DE-thorsten-high.tar.bz2.
  Jeu de données **Thorsten-Voice**, publié sous **CC0** :
  https://github.com/thorstenMueller/Thorsten-Voice ;
  https://creativecommons.org/publicdomain/zero/1.0/.
  Source vocale à 22,05 kHz, rééchantillonnée dans le mix à 48 kHz.
  La fiche fournie avec le modèle est conservée dans
  `assets/audio/VOICE-MODEL-CARD.txt`.
  Moteur sherpa-onnx sous Apache-2.0 : https://github.com/k2-fsa/sherpa-onnx.
- **Portrait de Cristiano Ronaldo** — `assets/images/ronaldo-siuu.png`, PNG
  RGBA de 1024 × 1536 pixels avec fond transparent. Création générée pour ce
  film avec l’outil de génération d’images d’OpenAI à partir d’une description
  de Ronaldo en tenue du Portugal, en célébration SIUU, avec lumière périphérique
  dorée. Le portrait retenu est recadré par CSS dans l’ouverture et la finale.
- **Musique et effets** — créations synthétiques originales pour ce projet,
  reproduites par les scripts fournis dans `scripts/`.

HyperFrames 0.8.145 déclare la licence Apache-2.0. Les dépendances npm restent
couvertes par leurs licences respectives, distribuées avec les paquets installés
par `npm ci`.
