/* Collector-grade vector props. No remote imagery or autonomous animation. */
(function () {
  'use strict';
  const ball = `<svg class="trophy-vector trophy-ball-vector" viewBox="0 0 400 500" fill="none" aria-hidden="true" focusable="false">
    <defs>
      <radialGradient id="cr7-ball-gold" cx=".32" cy=".23" r=".85"><stop stop-color="#FFFDCB"/><stop offset=".18" stop-color="#F9DC74"/><stop offset=".39" stop-color="#D7A435"/><stop offset=".6" stop-color="#A77221"/><stop offset=".79" stop-color="#D9A942"/><stop offset=".91" stop-color="#6D451D"/><stop offset="1" stop-color="#2C2314"/></radialGradient>
      <linearGradient id="cr7-ball-rim" x1="86" y1="80" x2="302" y2="294" gradientUnits="userSpaceOnUse"><stop stop-color="#FFF6AB"/><stop offset=".36" stop-color="#BE842A"/><stop offset=".65" stop-color="#FFE9A1"/><stop offset="1" stop-color="#724914"/></linearGradient>
      <radialGradient id="cr7-ball-bounce" cx=".68" cy=".85" r=".7"><stop stop-color="#FFED93" stop-opacity=".63"/><stop offset=".45" stop-color="#C89430" stop-opacity=".08"/><stop offset="1" stop-color="#BE7621" stop-opacity="0"/></radialGradient>
      <radialGradient id="cr7-ball-white" cx=".28" cy=".19" r=".53"><stop stop-color="#FFFFE3" stop-opacity=".78"/><stop offset=".25" stop-color="#FFFED0" stop-opacity=".21"/><stop offset="1" stop-color="#FFFDD1" stop-opacity="0"/></radialGradient>
      <linearGradient id="cr7-ball-rock" x1="122" y1="315" x2="287" y2="478" gradientUnits="userSpaceOnUse"><stop stop-color="#EBCE72"/><stop offset=".3" stop-color="#A78240"/><stop offset=".53" stop-color="#CDB869"/><stop offset=".76" stop-color="#4B3B24"/><stop offset="1" stop-color="#2D3026"/></linearGradient>
      <linearGradient id="cr7-ball-rock-light" x1="136" y1="325" x2="211" y2="440" gradientUnits="userSpaceOnUse"><stop stop-color="#FFF0B2"/><stop offset=".36" stop-color="#BE9953"/><stop offset=".64" stop-color="#E5CB88"/><stop offset="1" stop-color="#76613B"/></linearGradient>
      <linearGradient id="cr7-ball-rock-dark" x1="229" y1="335" x2="286" y2="461" gradientUnits="userSpaceOnUse"><stop stop-color="#B29750"/><stop offset=".49" stop-color="#4B4028"/><stop offset="1" stop-color="#8D7743"/></linearGradient>
      <clipPath id="cr7-ball-sphere-clip"><circle cx="200" cy="184" r="127"/></clipPath>
    </defs>
    <!-- A faceted pyrite mineral base, with actual depth at its torn edges. -->
    <path d="M106 337 138 317 165 299 196 311 225 300 252 321 279 334 294 367 278 411 294 442 270 472 122 472 100 451 91 411 98 373Z" fill="url(#cr7-ball-rock)" stroke="#D8B969" stroke-width="1.2"/>
    <path d="m138 317 27-18 31 12-20 40-43 9-27-23Z" fill="url(#cr7-ball-rock-light)"/>
    <path d="m196 311 29-11 27 21-18 27-28 5-30-2Z" fill="#A68848"/>
    <path d="m252 321 27 13 15 33-37 20-23-39Z" fill="url(#cr7-ball-rock-dark)"/>
    <path d="m106 337 27 23-15 28-20-15Z" fill="#F1D191"/>
    <path d="m133 360 43-9 8 38-34 23-32-24Z" fill="url(#cr7-ball-rock-light)"/>
    <path d="m176 351 30 2 28-5 23 39-37 17-36-15Z" fill="#D9C282"/>
    <path d="m98 373 20 15 32 24-15 29-35 10-9-40Z" fill="#8B7446"/>
    <path d="m150 412 34-23 36 15-17 30-25 18-43-11Z" fill="#BDAA6B"/>
    <path d="m220 404 37-17 37-20-16 44 16 31-37 9-28-19-26 2Z" fill="url(#cr7-ball-rock-dark)"/>
    <path d="m100 451 35-10 43 11 25-18 26-2 28 19 37-9-24 30H122Z" fill="#635A37"/>
    <path d="m138 317 27-18 31 12m-90 26 27 23 43-9 30 2 28-5 18-27m-134 67 32 24 34-23 36 15 37-17m-122 54 43 11 25-18 26-2 28 19" stroke="#F9E4AC" stroke-opacity=".45" stroke-width="1.4" stroke-linejoin="round"/>
    <g fill="#F8E0A0" opacity=".66"><path d="m111 372 14-7-4 13-9 4Z"/><path d="m145 388 10-4 5 7-10 7Z"/><path d="m197 365 12-3 5 8-11 8Z"/><path d="m237 392 8-5 7 5-8 7Z"/><path d="m138 431 8-6 5 4-7 8Z"/><path d="m187 446 9-7 6 3-8 8Z"/></g>
    <g fill="#393A23" opacity=".75"><path d="m124 352 8-8 5 10-7 7Z"/><path d="m175 374 7-9 7 9-6 6Z"/><path d="m267 361 8-3 3 8-7 5Z"/><path d="m161 415 8-2 4 7-8 4Z"/><path d="m229 445 10-8 7 7-11 9Z"/></g>
    <g fill="#FFF2BD" opacity=".52"><path d="m132 333 14-5 5 6-14 6Z"/><path d="m152 343 12-5 6 5-14 7Z"/><path d="m181 327 12-7 8 5-12 9Z"/><path d="m217 322 7-4 9 6-8 5Z"/><path d="m244 341 12 2 3 10-11-3Z"/><path d="m259 357 10 1 3 9-9-2Z"/><path d="m123 397 10 4-3 8-10-5Z"/><path d="m153 375 9-5 8 5-10 7Z"/><path d="m162 393 8 3-4 6-7-3Z"/><path d="m190 400 7 3-2 9-8-4Z"/><path d="m205 382 12-7 7 5-12 8Z"/><path d="m246 418 13-5 5 8-14 5Z"/><path d="m267 436 12 1-5 8-10-1Z"/><path d="m141 450 12 1 4 8-12-2Z"/><path d="m183 461 8-5 7 3-6 6Z"/></g>
    <g stroke="#645528" stroke-opacity=".55" stroke-width=".8"><path d="m133 360 19-17 24 8m-58 37 18 2 14 22m26-61 8 17 22-15m-22 36 21-7 15 22m14-56 5 19 18 20m-54 47 9 16 17-18m-79-20 15 12-30 17"/></g>
    <ellipse cx="200" cy="310" rx="49" ry="11" fill="#473616" opacity=".8"/>
    <!-- Reflective spherical panels. Fine double seams imitate engraved metal. -->
    <circle cx="200" cy="184" r="129" fill="#624516"/>
    <circle cx="200" cy="184" r="127" fill="url(#cr7-ball-gold)" stroke="url(#cr7-ball-rim)" stroke-width="2.2"/>
    <g clip-path="url(#cr7-ball-sphere-clip)">
      <path d="m200 132 43 29-14 50-53 4-25-45Z" fill="#704715" fill-opacity=".14"/>
      <path d="m200 132 2-64 40 2 42 25 4 44-45 22Z" fill="#FFF0AE" fill-opacity=".12"/>
      <path d="m151 170-44-28 6-46 47-27 42-1-2 64Z" fill="#FFF3B1" fill-opacity=".11"/>
      <path d="m151 170 25 45-45 31-40-36-1-45 17-23Z" fill="#734814" fill-opacity=".12"/>
      <path d="m229 211 41 32 40-31 2-46-24-27-45 22Z" fill="#523711" fill-opacity=".1"/>
      <path d="m176 215 53-4 41 32-19 37-54 11-52-18-14-27Z" fill="#FFE393" fill-opacity=".12"/>
      <path id="cr7-ball-seams" d="m200 132 43 29-14 50-53 4-25-45 49-38Zm0 0 2-64 40 2 42 25 4 44-45 22m-92 9-44-28 6-46 47-27 42-1m-89 28-20-41-44 42m58 45-17 23 1 45 40 36 45-31m53-4 41 32 40-31 2-46-24-27m-4-44 42-9 18 51-32 29m-181 80 14 27 52 18 54-11 19-37m-73 48-2 46m56-57 37 25m-143-32-28 36m-26-99-32 8m39-121 23-39m82 13 18-24" stroke="#6C491C" stroke-opacity=".65" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="m200 132 43 29-14 50-53 4-25-45 49-38Zm0 0 2-64 40 2 42 25 4 44-45 22m-92 9-44-28 6-46 47-27 42-1m-89 28-20-41-44 42m58 45-17 23 1 45 40 36 45-31m53-4 41 32 40-31 2-46-24-27m-4-44 42-9 18 51-32 29m-181 80 14 27 52 18 54-11 19-37m-73 48-2 46m56-57 37 25m-143-32-28 36m-26-99-32 8m39-121 23-39m82 13 18-24" stroke="#FFE6A4" stroke-opacity=".65" stroke-width=".75" stroke-linecap="round" stroke-linejoin="round"/>
      <circle cx="200" cy="184" r="127" fill="url(#cr7-ball-bounce)"/>
      <circle cx="200" cy="184" r="127" fill="url(#cr7-ball-white)"/>
      <path d="M222 69C257 90 270 155 264 208C261 236 251 261 237 279C260 251 277 223 281 183C286 133 265 88 241 69Z" fill="#FFF8C0" opacity=".1"/>
      <path d="M87 168C91 113 127 78 174 67" stroke="#FFF6C5" stroke-opacity=".82" stroke-width="3.8" stroke-linecap="round"/>
      <path d="M300 151c14 55-6 107-46 134" stroke="#FFE391" stroke-opacity=".47" stroke-width="2.8" stroke-linecap="round"/>
      <ellipse cx="155" cy="109" rx="46" ry="27" fill="#FFFFE0" opacity=".12"/>
    </g>
    <path class="trophy-glint" d="m129 88 3-13 3 13 13 3-13 3-3 13-3-13-13-3Z" fill="#FFFCD8"/>
    <path class="trophy-glint trophy-glint-small" d="m268 281 2-8 2 8 8 2-8 2-2 8-2-8-8-2Z" fill="#FFF1B0" opacity=".85"/>
  </svg>`;

  const ucl = `<svg class="trophy-vector trophy-ucl-vector" viewBox="0 0 400 500" fill="none" aria-hidden="true" focusable="false">
    <defs>
      <linearGradient id="cr7-ucl-chrome" x1="116" y1="0" x2="285" y2="0" gradientUnits="userSpaceOnUse"><stop stop-color="#283F3D"/><stop offset=".08" stop-color="#849F98"/><stop offset=".18" stop-color="#F0FBF7"/><stop offset=".27" stop-color="#C2D5CB"/><stop offset=".36" stop-color="#6B9184"/><stop offset=".43" stop-color="#23493E"/><stop offset=".48" stop-color="#A5C1B3"/><stop offset=".62" stop-color="#DBEAE3"/><stop offset=".77" stop-color="#ECF9F3"/><stop offset=".86" stop-color="#8BABA0"/><stop offset=".93" stop-color="#253E35"/><stop offset="1" stop-color="#BBDBCD"/></linearGradient>
      <linearGradient id="cr7-ucl-handles" x1="38" y1="43" x2="137" y2="277" gradientUnits="userSpaceOnUse"><stop stop-color="#E7F8F3"/><stop offset=".16" stop-color="#91B2A5"/><stop offset=".28" stop-color="#EBFFF8"/><stop offset=".4" stop-color="#31584A"/><stop offset=".58" stop-color="#94B8A6"/><stop offset=".73" stop-color="#EEFDF5"/><stop offset=".88" stop-color="#6B9989"/><stop offset="1" stop-color="#18382F"/></linearGradient>
      <linearGradient id="cr7-ucl-lip" x1="109" y1="74" x2="285" y2="119" gradientUnits="userSpaceOnUse"><stop stop-color="#A1BBB1"/><stop offset=".23" stop-color="#F5FFFC"/><stop offset=".5" stop-color="#779A8A"/><stop offset=".74" stop-color="#DDF3E8"/><stop offset="1" stop-color="#779C8A"/></linearGradient>
      <linearGradient id="cr7-ucl-interior" x1="200" y1="74" x2="200" y2="119" gradientUnits="userSpaceOnUse"><stop stop-color="#1A382E"/><stop offset=".4" stop-color="#5D8571"/><stop offset="1" stop-color="#152A23"/></linearGradient>
      <linearGradient id="cr7-ucl-base" x1="119" y1="424" x2="282" y2="481" gradientUnits="userSpaceOnUse"><stop stop-color="#273E32"/><stop offset=".18" stop-color="#B1C7B3"/><stop offset=".3" stop-color="#3B5541"/><stop offset=".6" stop-color="#12231A"/><stop offset=".8" stop-color="#4C6956"/><stop offset="1" stop-color="#0E1C14"/></linearGradient>
      <linearGradient id="cr7-ucl-flare" x1="146" y1="0" x2="255" y2="0" gradientUnits="userSpaceOnUse"><stop stop-color="#395244"/><stop offset=".21" stop-color="#D2E8DC"/><stop offset=".38" stop-color="#60876C"/><stop offset=".59" stop-color="#A2C1AE"/><stop offset=".76" stop-color="#E9FDF1"/><stop offset="1" stop-color="#385444"/></linearGradient>
      <linearGradient id="cr7-ucl-engrave" x1="176" y1="174" x2="229" y2="232" gradientUnits="userSpaceOnUse"><stop stop-color="#496C5C"/><stop offset=".46" stop-color="#BBD4C3"/><stop offset="1" stop-color="#31503E"/></linearGradient>
    </defs>
    <!-- The iconic large ears are wide metal ribbons rather than thin wire. -->
    <path id="cr7-ucl-left-handle" d="M142 117C117 126 109 102 102 78C94 46 79 19 58 27C22 39 26 89 37 132C53 204 91 259 150 286L162 262C118 242 84 194 67 140C54 100 44 56 59 48C70 44 79 65 86 87C96 121 111 153 145 142Z" fill="url(#cr7-ucl-handles)" stroke="#203D33" stroke-width="2" stroke-linejoin="round"/>
    <path d="M141 123C119 131 107 105 98 78C90 50 77 23 59 31C28 43 32 87 43 130C58 194 94 253 153 279" stroke="#F1FFF7" stroke-opacity=".75" stroke-width="2.7" stroke-linecap="round"/>
    <path d="M144 137C109 147 98 111 90 85C80 50 65 38 55 47C39 61 53 108 64 143C81 199 113 246 157 269" stroke="#315B48" stroke-opacity=".8" stroke-width="2.8" stroke-linecap="round"/>
    <g transform="translate(400 0) scale(-1 1)"><use href="#cr7-ucl-left-handle"/><path d="M141 123C119 131 107 105 98 78C90 50 77 23 59 31C28 43 32 87 43 130C58 194 94 253 153 279" stroke="#F1FFF7" stroke-opacity=".83" stroke-width="2.7" stroke-linecap="round"/><path d="M144 137C109 147 98 111 90 85C80 50 65 38 55 47C39 61 53 108 64 143C81 199 113 246 157 269" stroke="#315B48" stroke-opacity=".76" stroke-width="2.8" stroke-linecap="round"/></g>
    <!-- The body is reflected emerald and white chrome, with a deep open mouth. -->
    <path d="M117 98C132 88 271 88 284 98L278 159C269 221 254 284 232 315L229 347L246 375L253 413H147L154 375L173 347L170 315C148 287 133 225 124 159Z" fill="url(#cr7-ucl-chrome)" stroke="#B8D5C8" stroke-width="1.3"/>
    <path d="M131 113C139 198 148 265 179 317L182 349L164 377L160 409" stroke="#F1FFF8" stroke-opacity=".66" stroke-width="4.4" stroke-linecap="round"/>
    <path d="M265 114C257 196 249 268 223 314L220 349L237 378L242 409" stroke="#E9FFF0" stroke-opacity=".4" stroke-width="2.2" stroke-linecap="round"/>
    <path d="M148 115C151 183 160 270 186 308L188 347L174 380L171 408" stroke="#E1F1E6" stroke-opacity=".2" stroke-width="12" stroke-linecap="round"/>
    <path d="M222 119C230 165 236 242 212 308L211 350L223 391" stroke="#F8FFFC" stroke-opacity=".16" stroke-width="9" stroke-linecap="round"/>
    <path d="M145 249C174 260 231 260 256 249" stroke="#F2FFF4" stroke-opacity=".14" stroke-width="1.6"/>
    <ellipse cx="200" cy="98" rx="85" ry="24" fill="url(#cr7-ucl-lip)" stroke="#D7F4E5" stroke-width="1.2"/>
    <ellipse cx="200" cy="96" rx="76" ry="16.2" fill="url(#cr7-ucl-interior)" stroke="#204137" stroke-width="1.5"/>
    <path d="M117 98C143 128 259 128 283 98" stroke="#F1FFF9" stroke-width="4" stroke-linecap="round"/>
    <path d="M126 90C151 72 248 72 274 90" stroke="#C8E8D8" stroke-width="2" stroke-opacity=".82"/>
    <!-- A small embossed ball and laurels read as engraving, with no caption. -->
    <g stroke="url(#cr7-ucl-engrave)" stroke-width="1.5" stroke-linejoin="round" opacity=".8"><circle cx="200" cy="194" r="24"/><path d="m200 181 12 8-5 14-14 0-5-14 12-8Zm0 0v-11m12 19 11-4m-16 18 8 11m-22-11-8 11m3-25-11-4"/><path d="M172 180c-14 27-4 48 17 54m39-54c14 27 4 48-17 54"/><path d="m170 185-6-4 2 9 5 3m-2 4-7-2 4 8 5 1m0 5-6 1 6 6 5-1m1 5-4 4 8 3 4-4m-2 8-2 5 9 0 3-4m40-44 6-4-2 9-5 3m2 4 7-2-4 8-5 1m0 5 6 1-6 6-5-1m-1 5 4 4-8 3-4-4m2 8 2 5-9 0-3-4"/></g>
    <path d="M171 315C187 321 215 321 231 315M174 344C186 348 214 348 226 344" stroke="#D7F0DD" stroke-opacity=".6" stroke-width="1.8"/>
    <path d="M153 375C175 366 225 366 247 375L254 414C226 427 174 427 146 414Z" fill="url(#cr7-ucl-flare)" stroke="#AFCBBA" stroke-width="1.2"/>
    <ellipse cx="200" cy="414" rx="54" ry="12" fill="#C3DBCB" stroke="#294A36" stroke-width="1.1"/>
    <path d="M146 414C160 429 239 429 254 414V435C237 449 162 449 146 435Z" fill="url(#cr7-ucl-base)" stroke="#8AA997" stroke-width="1"/>
    <ellipse cx="200" cy="436" rx="55" ry="12" fill="#4A6854" stroke="#B9D4C2" stroke-width="1.1"/>
    <path d="M125 449C141 433 260 433 276 449V468C255 484 144 484 125 468Z" fill="url(#cr7-ucl-base)" stroke="#729180" stroke-width="1.1"/>
    <ellipse cx="200" cy="449" rx="76" ry="13" fill="url(#cr7-ucl-flare)" stroke="#C7E4D0" stroke-width="1.2"/>
    <path d="M130 465C155 479 248 479 271 465" stroke="#ABCBB7" stroke-opacity=".63" stroke-width="1.5"/>
    <path class="trophy-glint" d="m135 117 3-14 3 14 14 3-14 3-3 14-3-14-14-3Z" fill="#EFFFF6"/>
    <path class="trophy-glint trophy-glint-small" d="m307 55 2-9 2 9 9 2-9 2-2 9-2-9-9-2Z" fill="#E7FFF4" opacity=".8"/>
  </svg>`;
  window.CR7Trophies = {ball,ucl};
})();
