#!/usr/bin/env python3
"""Original 15-second CR7 score, transition SFX, voice carve and final mix.

Dependencies: Python 3, NumPy and ffmpeg. Inputs: frozen voice-stem.wav and
voice-cues.json. No downloaded musical samples or commercial recordings.
"""
from __future__ import annotations

import argparse
import json
import math
import subprocess
import tempfile
import wave
from pathlib import Path

import numpy as np

SR = 48_000
N = 15 * SR
RNG = np.random.default_rng(7_0900_0505)


def time(seconds: float) -> np.ndarray:
    return np.arange(round(seconds * SR), dtype=np.float64) / SR


def edges(y: np.ndarray, attack: float = 0.003, release: float = 0.025) -> np.ndarray:
    y = y.copy()
    left = min(round(attack * SR), len(y))
    right = min(round(release * SR), len(y))
    if left:
        y[:left] *= np.sin(np.linspace(0, np.pi / 2, left)) ** 2
    if right:
        y[-right:] *= np.cos(np.linspace(0, np.pi / 2, right)) ** 2
    return y


def pan(y: np.ndarray, balance: float = 0) -> np.ndarray:
    angle = (balance + 1) * np.pi / 4
    return np.column_stack((y * np.cos(angle), y * np.sin(angle)))


def noise(seconds: float, lo: float, hi: float) -> np.ndarray:
    count = round(seconds * SR)
    y = RNG.standard_normal(count)
    f = np.fft.rfftfreq(count, 1 / SR)
    spectrum = np.fft.rfft(y)
    spectrum *= (1 - np.exp(-(f / lo) ** 4)) * np.exp(-(f / hi) ** 4)
    y = np.fft.irfft(spectrum, n=count)
    y /= max(np.sqrt(np.mean(y * y)), 1e-12)
    return np.tanh(y / 1.6) * 1.4


def place(track: np.ndarray, y: np.ndarray, at: float, gain: float = 1, balance: float = 0) -> None:
    if y.ndim == 1:
        y = pan(y, balance)
    start = round(at * SR)
    offset = max(0, -start)
    start = max(0, start)
    length = min(len(y) - offset, N - start)
    if length > 0:
        track[start:start + length] += y[offset:offset + length] * gain


def pluck(freq: float, seconds: float = 0.45) -> np.ndarray:
    t = time(seconds)
    envelope = (1 - np.exp(-t / 0.004)) * np.exp(-t / 0.14)
    y = np.sin(2 * np.pi * freq * t)
    y += 0.26 * np.sin(2 * np.pi * freq * 2 * t) * np.exp(-t / 0.08)
    y += 0.065 * np.sin(2 * np.pi * freq * 3 * t) * np.exp(-t / 0.035)
    return edges(y * envelope)


def tom(seconds: float = 0.42) -> np.ndarray:
    t = time(seconds)
    phase = 2 * np.pi * (50 * t + 95 * 0.025 * (1 - np.exp(-t / 0.025)))
    env = (1 - np.exp(-t / 0.001)) * np.exp(-t / 0.095)
    y = np.sin(phase) * env
    y += noise(seconds, 650, 2400) * np.exp(-t / 0.012) * 0.035
    return edges(y, 0.0015, 0.025)


def impact(seconds: float = 0.95) -> np.ndarray:
    t = time(seconds)
    phase = 2 * np.pi * (40 * t + 110 * 0.045 * (1 - np.exp(-t / 0.045)))
    low = np.sin(phase) * (1 - np.exp(-t / 0.001)) * np.exp(-t / 0.23)
    top = noise(seconds, 350, 4200) * np.exp(-t / 0.042) * 0.16
    metal = (np.sin(2 * np.pi * 1174.66 * t) * 0.07 + np.sin(2 * np.pi * 1567.98 * t) * 0.05)
    metal *= np.exp(-t / 0.12)
    return edges(low + top + metal)


def air(seconds: float = 0.45) -> np.ndarray:
    t = time(seconds)
    x = t / seconds
    envelope = np.sin(x * np.pi) ** 1.4
    y = noise(seconds, 380, 5200) * envelope * 0.09
    y += np.sin(2 * np.pi * (480 * t + 1200 * t * t / seconds)) * envelope * 0.025
    y = edges(y)
    angle = (-0.7 + 1.4 * x + 1) * np.pi / 4
    return np.column_stack((y * np.cos(angle), y * np.sin(angle)))


def read(path: Path) -> np.ndarray:
    with wave.open(str(path), 'rb') as wav:
        if (wav.getframerate(), wav.getnchannels(), wav.getsampwidth(), wav.getnframes()) != (SR, 2, 2, N):
            raise ValueError(f'{path.name}: 15s 48kHz stereo PCM16 required')
        return np.frombuffer(wav.readframes(N), dtype='<i2').reshape(-1, 2).astype(np.float64) / 32768


def write(path: Path, y: np.ndarray) -> None:
    if np.max(np.abs(y)) >= 1:
        raise ValueError(f'{path.name}: clipping')
    with wave.open(str(path), 'wb') as wav:
        wav.setnchannels(2)
        wav.setsampwidth(2)
        wav.setframerate(SR)
        wav.writeframes(np.round(y * 32767).astype('<i2').tobytes())


def meter(path: Path) -> dict:
    result = subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-i', str(path), '-af',
                             'loudnorm=I=-16:TP=-2:LRA=7:print_format=json', '-f', 'null', '-'],
                            check=True, capture_output=True, text=True)
    text = result.stderr
    return json.loads(text[text.rfind('{'):text.rfind('}') + 1])


def voice_envelope(takes: list[dict]) -> np.ndarray:
    t = time(15)
    total = np.zeros(N)
    for take in takes:
        attack = np.clip((t - take['start'] + 0.09) / 0.09, 0, 1)
        release = np.clip((take['end'] + 0.15 - t) / 0.15, 0, 1)
        y = np.minimum(attack, release)
        total = np.maximum(total, y * y * (3 - 2 * y))
    return total


def build(out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    cues = json.loads((out / 'voice-cues.json').read_text(encoding='utf-8'))
    voice = read(out / 'voice-stem.wav')
    music = np.zeros((N, 2))
    sfx = np.zeros((N, 2))
    t = time(15)
    # Restrained orchestral-colour electronic bed in D minor, then Bb/D.
    chords = [(0, 3.5, [73.4162, 110, 146.8324, 174.6141]),
              (3.5, 7.5, [73.4162, 146.8324, 220, 261.6256]),
              (7.5, 11.5, [65.4064, 130.8128, 174.6141, 220]),
              (11.5, 15, [73.4162, 116.5409, 146.8324, 220])]
    for start, end, notes in chords:
        local = time(end - start)
        gate = np.minimum(np.clip(local / 0.20, 0, 1), np.clip((end - start - local) / 0.32, 0, 1))
        left = np.zeros_like(local)
        right = np.zeros_like(local)
        for i, freq in enumerate(notes):
            phase = i * 0.47
            weight = 0.010 if i == 0 else 0.008
            left += (np.sin(2 * np.pi * freq * local + phase) + 0.17 * np.sin(4 * np.pi * freq * local)) * weight
            right += (np.sin(2 * np.pi * freq * 1.00025 * local + phase + 0.11) +
                      0.17 * np.sin(4 * np.pi * freq * 1.0001 * local)) * weight
        place(music, np.column_stack((left * gate, right * gate)), start)
    shimmer = noise(15, 1900, 5600) * 0.0017 * (0.7 + 0.3 * np.sin(t * 0.8))
    music += np.column_stack((shimmer, np.roll(shimmer, 320)))
    for beat in range(29):
        at = beat * 0.5
        place(music, tom(), at, 0.102 if beat % 4 == 0 else 0.068)
        bass = 73.4162 if at < 7.5 or at >= 11.5 else 65.4064
        place(music, pluck(bass, 0.46), at + 0.015, 0.043)
        # A small upper tick marks the stride, with ample space for consonants.
        if at < 14:
            tick_t = time(0.10)
            tick = noise(0.10, 2000, 6500) * np.exp(-tick_t / 0.013) * 0.018
            place(music, edges(tick, 0.0008, 0.010), at + 0.25, balance=(-0.35 if beat % 2 else 0.35))
    arp = [293.6648, 349.2282, 440, 523.2511, 440, 349.2282]
    for step in range(32):
        at = 3.625 + step * 0.25
        place(music, pluck(arp[step % len(arp)], 0.50), at, 0.019,
              balance=(-0.18 if step % 2 else 0.18))
    for at, level in [(0, 0.20), (3.5, 0.17), (7.5, 0.17), (11.5, 0.20)]:
        place(sfx, impact(), at, level)
    for at in [3.25, 7.25, 11.25]:
        place(sfx, air(0.48), at, 0.84)
    # Original brief crystalline trophy details; no borrowed stadium samples.
    for at, freq in [(3.72, 1174.66), (4.14, 1567.98), (4.56, 1760), (7.80, 1046.5)]:
        place(sfx, pluck(freq, 0.42), at, 0.024)
    # Final chord arrives after the last spoken word rather than cutting it.
    for freq in [293.6648, 440, 587.3295]:
        place(sfx, pluck(freq, 0.40), 14.80, 0.020)
    release = np.ones(N)
    start = round(14.35 * SR)
    release[start:] = np.cos(np.linspace(0, np.pi / 2, N - start)) ** 2
    release[-1] = 0
    music *= release[:, None]
    sfx *= release[:, None]
    write(out / 'music-stem.wav', music)
    write(out / 'sfx-stem.wav', sfx)
    write(out / 'instrumental.wav', music + sfx)
    duck = voice_envelope(cues['takes'])[:, None]
    with tempfile.TemporaryDirectory(prefix='cr7-mix-', dir=str(out)) as temp:
        temp_dir = Path(temp)
        carved_path = temp_dir / 'carved.wav'
        subprocess.run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-i', str(out / 'music-stem.wav'),
                        '-af', 'equalizer=f=250:t=q:w=0.9:g=-2,equalizer=f=1100:t=q:w=0.8:g=-4,'
                        'equalizer=f=2600:t=q:w=0.9:g=-3.5', '-ar', str(SR), '-ac', '2',
                        '-c:a', 'pcm_s16le', str(carved_path)], check=True)
        carved = read(carved_path)
        background = (music * (1 - duck) + carved * duck) * (1 - duck * 0.75)
        background += sfx * (1 - duck * 0.55)
        mix = voice + background
        initial_gain = min(1.0, 0.90 / np.max(np.abs(mix)))
        raw = temp_dir / 'premaster.wav'
        write(raw, mix * initial_gain)
        stats = meter(raw)
        gain_db = min(-16.0 - float(stats['input_i']), -2.0 - float(stats['input_tp']))
        gain = initial_gain * 10 ** (gain_db / 20)
        master = mix * gain
        write(out / 'cr7-master.wav', master)
        write(out / 'ducked-background.wav', background * gain)
        write(out / 'voice-mix-stem.wav', voice * gain)
    final = meter(out / 'cr7-master.wav')
    metadata = {
        'master': 'cr7-master.wav', 'durationSeconds': 15, 'sampleRate': SR, 'channels': 2,
        'pcmBits': 16, 'bpm': 120, 'music': 'Original procedural score: D minor/Bb, deep pulse, restrained arpeggio',
        'license': 'Original project music and SFX, no sampled third-party recordings',
        'integratedLUFS': float(final['input_i']), 'truePeakDbTP': float(final['input_tp']),
        'loudnessRangeLU': float(final['input_lra']),
        'samplePeakDbFS': round(20 * math.log10(float(np.max(np.abs(master)))), 3),
        'musicDuckDb': -12.04, 'sfxDuckDb': -6.94, 'duckAttackSeconds': 0.09, 'duckReleaseSeconds': 0.15,
        'spectralCarve': [{'frequencyHz': 250, 'gainDb': -2}, {'frequencyHz': 1100, 'gainDb': -4},
                          {'frequencyHz': 2600, 'gainDb': -3.5}],
        'sfxCues': [{'time': at, 'kind': 'cinematic-impact', 'frame60': round(at * 60)} for at in [0, 3.5, 7.5, 11.5]] +
                   [{'time': at, 'kind': 'transition-air', 'frame60': round(at * 60)} for at in [3.25, 7.25, 11.25]] +
                   [{'time': 14.80, 'kind': 'final-resolve', 'frame60': 888}],
        'voiceRanges': [{'id': x['id'], 'start': x['start'], 'end': x['end']} for x in cues['takes']],
        'voiceFade': 'No global fade on speech; the full last word completes before 14.80s',
    }
    (out / 'audio-mix.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=Path(__file__).resolve().parent.parent / 'assets' / 'audio')
    args = parser.parse_args()
    build(args.out)
