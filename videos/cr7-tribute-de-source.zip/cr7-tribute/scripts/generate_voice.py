#!/usr/bin/env python3
"""Generate the complete German CR7 narration with local neural Piper/VITS.

Dependencies: Python 3, sherpa-onnx==1.13.8, numpy, soundfile, ffmpeg.
Render-time playback uses frozen WAV files and never runs a neural model.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import tempfile
from pathlib import Path

import numpy as np
import sherpa_onnx
import soundfile as sf

SR = 48_000
EXACT_USER_TEXT = ('Cristiano Ronaldo ist eine absolute Legende des Weltfußballs: '
                  '5-maliger Ballon-d’Or-Gewinner, 5 Champions-League-Titel, '
                  'Europameister mit Portugal und der Rekordtorschütze der Geschichte '
                  'des Profifußballs mit über 900 Toren. Ein Vorbild an Arbeitsmoral '
                  'und Beständigkeit auf höchstem Niveau.')
LINES = [
    {'id': 'legende', 'start': 0.25, 'latestEnd': 3.47, 'speed': 1.10,
     'text': 'Cristiano Ronaldo ist eine absolute Legende des Weltfußballs:',
     'spokenText': 'Cristiano Ronaldo ist eine absolute Legende des Weltfußballs:'},
    {'id': 'titel', 'start': 3.58, 'latestEnd': 7.42, 'speed': 1.08,
     'text': '5-maliger Ballon-d’Or-Gewinner, 5 Champions-League-Titel,',
     'spokenText': 'Fünfmaliger Ballon-d’Or-Gewinner, fünf Champions-League-Titel,'},
    {'id': 'tore', 'start': 7.63, 'latestEnd': 11.40, 'speed': 1.65,
     'text': 'Europameister mit Portugal und der Rekordtorschütze der Geschichte des Profifußballs mit über 900 Toren.',
     'spokenText': 'Europameister mit Portugal und der Rekordtorschütze der Geschichte des Profifußballs mit über neunhundert Toren.'},
    {'id': 'vorbild', 'start': 11.64, 'latestEnd': 14.82, 'speed': 1.20,
     'text': 'Ein Vorbild an Arbeitsmoral und Beständigkeit auf höchstem Niveau.',
     'spokenText': 'Ein Vorbild an Arbeitsmoral und Beständigkeit auf höchstem Niveau.'},
]


def generate(model_dir: Path, out: Path, only: set[str] | None = None) -> None:
    out.mkdir(parents=True, exist_ok=True)
    model_path = model_dir / 'de_DE-thorsten-high.onnx'
    config = sherpa_onnx.OfflineTtsConfig(
        model=sherpa_onnx.OfflineTtsModelConfig(
            vits=sherpa_onnx.OfflineTtsVitsModelConfig(
                model=str(model_path), tokens=str(model_dir / 'tokens.txt'),
                data_dir=str(model_dir / 'espeak-ng-data'),
                noise_scale=0.0, noise_scale_w=0.0),
            provider='cpu', num_threads=2, debug=False), max_num_sentences=1)
    if not config.validate():
        raise ValueError('Use the complete vits-piper-de_DE-thorsten-high model directory')
    engine = sherpa_onnx.OfflineTts(config)
    track = np.zeros((15 * SR, 2), dtype=np.float64)
    takes = []
    for index, line in enumerate(LINES, start=1):
        target = out / f'voice-{index:02d}-{line["id"]}.wav'
        if only is not None and line['id'] not in only:
            processed, sample_rate = sf.read(target, dtype='float64')
            duration = len(processed) / sample_rate
            at = round(line['start'] * SR)
            track[at:at + len(processed)] += processed[:, None]
            takes.append({**line, 'file': target.name, 'duration': round(duration, 6),
                          'end': round(line['start'] + duration, 6), 'sourceSampleRate': 22050,
                          'sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
            continue
        params = sherpa_onnx.GenerationConfig()
        params.sid, params.speed, params.silence_scale = 0, line['speed'], 0.12
        speech = engine.generate(line['spokenText'], params)
        y = np.asarray(speech.samples, dtype=np.float64)
        if not len(y):
            raise ValueError(f'Empty neural take: {line["id"]}')
        audible = np.flatnonzero(abs(y) > max(np.max(abs(y)) * 0.0014, 0.00005))
        left = max(0, int(audible[0]) - round(speech.sample_rate * 0.012))
        right = min(len(y), int(audible[-1]) + round(speech.sample_rate * 0.040))
        y = y[left:right]
        with tempfile.TemporaryDirectory(prefix='cr7-take-', dir=str(out)) as temp:
            raw = Path(temp) / 'raw.wav'
            sf.write(raw, y, speech.sample_rate, subtype='PCM_16')
            filters = ('highpass=f=65,lowpass=f=10500,'
                       'acompressor=threshold=0.11:ratio=2.5:attack=5:release=90:makeup=1.1,'
                       'loudnorm=I=-19:TP=-4:LRA=5')
            subprocess.run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error',
                            '-i', str(raw), '-af', filters, '-ar', str(SR),
                            '-ac', '1', '-c:a', 'pcm_s16le', str(target)], check=True)
        processed, sample_rate = sf.read(target, dtype='float64')
        duration = len(processed) / sample_rate
        end = line['start'] + duration
        if end > line['latestEnd']:
            raise ValueError(f'{line["id"]} ends at {end:.3f}s; raise TTS speed or extend scene, do not cut speech')
        at = round(line['start'] * SR)
        track[at:at + len(processed)] += processed[:, None]
        takes.append({**line, 'file': target.name, 'duration': round(duration, 6),
                      'end': round(end, 6), 'sourceSampleRate': speech.sample_rate,
                      'sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
    sf.write(out / 'voice-stem.wav', track, SR, subtype='PCM_16')
    (out / 'VOICE-MODEL-CARD.txt').write_text((model_dir / 'MODEL_CARD').read_text(), encoding='utf-8')
    metadata = {
        'exactUserText': EXACT_USER_TEXT,
        'voice': 'de_DE-thorsten-high, male, German (Germany)',
        'provider': 'Offline neural Piper VITS / sherpa-onnx 1.13.8',
        'modelSource': 'https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-de_DE-thorsten-high.tar.bz2',
        'modelSha256': hashlib.sha256(model_path.read_bytes()).hexdigest(),
        'dataset': 'Thorsten-Voice by Thorsten Müller',
        'datasetSource': 'https://github.com/thorstenMueller/Thorsten-Voice',
        'datasetLicense': 'CC0', 'engineLicense': 'Apache-2.0',
        'sourceSampleRate': 22050, 'sampleRate': SR, 'channels': 2, 'duration': 15,
        'spokenNormalization': '5-maliger→Fünfmaliger, 5→fünf, 900→neunhundert; full original content retained',
        'takes': takes,
    }
    (out / 'voice-cues.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model-dir', required=True, type=Path)
    parser.add_argument('--out', type=Path, default=Path(__file__).resolve().parent.parent / 'assets' / 'audio')
    parser.add_argument('--only', nargs='+', choices=[x['id'] for x in LINES],
                        help='Regenerate only selected takes; retain other frozen takes verbatim')
    args = parser.parse_args()
    generate(args.model_dir, args.out, set(args.only) if args.only else None)
