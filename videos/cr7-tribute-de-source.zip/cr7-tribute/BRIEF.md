---
workflow: general-video
flow: automation
storyboard: no
duration: 15
aspect: 9:16
language: de
---

# CR7 — Die Legende

Une carte de collection sportive présente Cristiano Ronaldo, son palmarès, son record et sa discipline. Format Reels/Shorts/TikTok 1080 × 1920, 60 images/s. Tous les textes à l’écran et la narration sont allemands. Texte parlé intégral fourni par l’utilisateur, sans réécriture.

Quatre séquences : légende 0–3,5 s ; trophées 3,5–7,5 s ; record 7,5–11,5 s ; discipline 11,5–15 s. Les fenêtres des cartes se recouvrent légèrement pendant les flips. Palette Onyx #111111, or métallique #D4AF37, émeraude #004D40 et blanc cassé. Inter variable locale, graisse 850–900, géométrie centrée, coins de viseur, grain subtil du papier, code-barres inférieur. Dernière pose stable.

Le visuel de Ronaldo est une création générée avec transparence, réutilisée en cadrage rapproché et en plein pied. Les trophées sont des SVG originaux avec volumes et reflets métalliques. Voix neuronale allemande masculine Thorsten, musique et impacts originaux, mix avec espace de fréquence et baisse du fond sous la parole. Livrer le MP4 et les sources dans le dépôt GitHub déjà choisi par l’utilisateur.
