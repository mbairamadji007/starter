# Carte de collection CR7

Le concept : une édition de collection révèle quatre facettes d’une même légende, chaque changement de carte répond à une phrase de la narration.

Canvas 1080 × 1920. Carte centrale : x=74, y=128, 932 × 1664 ; marges et coins de viseur fixes. Focales : Ronaldo détouré sur blanc, puis deux trophées métalliques sur émeraude, puis compteur doré 900+, puis Ronaldo en célébration sur noir. Texte essentiel dans une zone indépendante des figures ; code-barres et édition au bas de chaque carte.

Couleurs : #111111, #D4AF37, #004D40, #F2F0E8. Inter variable locale ; grands textes 65–117 px et compteur 300 px ; libellés 19–35 px. Chute de carte, perspective de flip, entrées par décalage et opacité, rouleaux numériques, arrêt final. Les déplacements sont des GSAP seeks déterministes ; aucune dérive de caméra au dernier plan. La photographie générée conserve ses couleurs et sa lumière périphérique d’or, sans filtre de grading ajouté.
